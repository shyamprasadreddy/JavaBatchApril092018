package com.cg.project.client;
import com.cg.project.exceptions.InValidRangeException;
import com.cg.project.services.MathServicesImpl;

public class MainClass {
	public static void main(String[] args) throws InValidRangeException {		
		int a=10,b=10;
		MathServicesImpl math =new MathServicesImpl();
		System.out.println(math.add(a,b)+" "+math.sub(a,b)+" "+math.div(a,b));
	}
}
