package com.cg.project.test;
import com.cg.project.exceptions.InValidRangeException;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.project.services.MathServices;
import com.cg.project.services.MathServicesImpl;



public class MathServicesTest {
	private static MathServices services;
	private int validNo1,validNo2,inValidNo1,inValidNo2,expectedAns;
	@BeforeClass
	public static void setUpTestEnv() {
		services=new MathServicesImpl();
	}
	@Before
	public  void setUpMockData() {
		validNo1=100;
		validNo2=20;
		inValidNo1=-20;
		inValidNo2=-53;
	}
	
	
	@Test(expected=InValidRangeException.class)
	public void testAddForFirstInvalidNo() throws InValidRangeException{
		services.add(inValidNo1, validNo2);
	}
	
	@Test(expected=InValidRangeException.class)
	public void testAddForSecondInvalidNo() throws InValidRangeException{
		services.add(validNo1, inValidNo2);
	}
	
	
	
	@Test
	public void testAddForValidNo() throws InValidRangeException {
		int actualAns=services.add(validNo1, validNo2);
		expectedAns=120;
		Assert.assertEquals(expectedAns, actualAns);
	}
	
	@Test(expected=InValidRangeException.class)
	public void testSubForFirstInvalidNo() throws InValidRangeException{
		services.add(inValidNo1, validNo2);
	}
	
	@Test(expected=InValidRangeException.class)
	public void testSubForSecondInvalidNo() throws InValidRangeException{
		services.add(validNo1, inValidNo2);
	}
	
	@Test
	public void testSubForValidNo() throws InValidRangeException {
		int actualAns=services.sub(validNo1, validNo2);
		expectedAns=80;
		Assert.assertEquals(expectedAns, actualAns);
	}
	
	@Test(expected=InValidRangeException.class)
	public void testDivForFirstInvalidNo() throws InValidRangeException{
		services.add(inValidNo1, validNo2);
	}
	
	@Test(expected=InValidRangeException.class)
	public void testDivForSecondInvalidNo() throws InValidRangeException{
		services.add(validNo1, inValidNo2);
	}
	@Test
	public void testDivForValidNo() throws InValidRangeException {
		int actualAns=services.div(validNo1,validNo2);
		expectedAns=5;
		Assert.assertEquals(expectedAns, actualAns);
	}
	
	
	@After
	public  void setDownMockdata() {
		validNo1=10;
		validNo2=20;
		inValidNo1=-20;
		inValidNo2=-53;
		expectedAns=0;
	}
	@AfterClass
	public static void setDownTestEnv() {
		services=null;
	}
	
}
