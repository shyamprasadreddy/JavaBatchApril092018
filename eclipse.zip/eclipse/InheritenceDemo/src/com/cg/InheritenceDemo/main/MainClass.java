package com.cg.InheritenceDemo.main;

import com.cg.InheritenceDemo.beans.CEmployee;
import com.cg.InheritenceDemo.beans.Employee;
import com.cg.InheritenceDemo.beans.PEmployee;
import com.cg.InheritenceDemo.beans.SalesManager;
import com.cg.InheritenceDemo.beans.Developer;
public class MainClass {
	
	public static void main(String[] args) {
		Employee employee=new Employee(111, 1500, "Satish", "Prasad");
		employee.calculateSalary();
		System.out.println(employee);
		
		employee=new PEmployee(112, 1000, "shyam", "prasad");
		employee.calculateSalary();
		System.out.println(employee);
		
		employee=new CEmployee(122, 145, "prasad", "reddy", 100);
		CEmployee cemp=(CEmployee) employee;
		employee.calculateSalary();
		cemp.signedContract();
		System.out.println(employee);
		
		employee=new SalesManager(113, 1000, "qw", "asd", 1000);
		SalesManager s=(SalesManager) employee;
		employee.calculateSalary();
		s.doAsales();
		System.out.println(employee);
		
		employee=new Developer(114, 3000, "zxcv", "asd", 50);
		Developer d=(Developer) employee;
		employee.calculateSalary();
		d.developeAProgram();
		System.out.println(employee);
	
	}

}
