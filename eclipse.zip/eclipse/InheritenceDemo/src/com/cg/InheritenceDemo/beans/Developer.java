package com.cg.InheritenceDemo.beans;

public final class Developer extends PEmployee{
	int noOfPrograms,incentive;

	public Developer() {
		super();

	}

	public Developer(int employeeId, int basicSalary, String firstName, String lastName,int noOfPrograms) {
		super(employeeId, basicSalary, firstName, lastName);
		this.noOfPrograms=noOfPrograms;
	}

	public int getNoOfPrograms() {
		return noOfPrograms;
	}

	public void setNoOfPrograms(int noOfPrograms) {
		this.noOfPrograms = noOfPrograms;
	}

	public int getIncentive() {
		return incentive;
	}

	public void setIncentive(int incentive) {
		this.incentive = incentive;
	}
	public void developeAProgram() {
		System.out.println("program developed ");
	}
	public void calculateSalary() {
		super.calculateSalary();
		this.setIncentive(noOfPrograms*5000);
		this.setTotalSalary(getIncentive()+this.getBasicSalary()+this.getHra()+this.getTa()+this.getDa());
	}

	@Override
	public String toString() {
		return super.toString() + "noOfPrograms=" + this.noOfPrograms + ", incentive=" + this.incentive ;
	}

}
