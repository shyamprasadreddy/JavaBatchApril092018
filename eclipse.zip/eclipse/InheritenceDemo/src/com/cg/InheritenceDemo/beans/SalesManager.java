package com.cg.InheritenceDemo.beans;

public final class SalesManager extends PEmployee{
	int saleAmt,commision;

	public SalesManager() {
		super();

	}

	public SalesManager(int employeeId, int basicSalary, String firstName, String lastName,int saleAmt) {
		super(employeeId, basicSalary, firstName, lastName);
		this.saleAmt=saleAmt;
	}

	public int getSaleAmt() {
		return saleAmt;
	}

	public void setSaleAmt(int saleAmt) {
		this.saleAmt = saleAmt;
	}

	public int getCommision() {
		return commision;
	}

	public void setCommision(int commision) {
		this.commision = commision;
	}
	public void doAsales() {
		System.out.println("done a sale");
	}
	public void calculateSalary() {
		super.calculateSalary();
		this.setCommision(1*saleAmt/100);
		this.setTotalSalary(getCommision()+this.getBasicSalary()+this.getHra()+this.getTa()+this.getDa());
	}

	@Override
	public String toString() {
		return super.toString() + "saleAmt=" + this.saleAmt + ", commision=" + this.commision ;
	}

	

	

}
