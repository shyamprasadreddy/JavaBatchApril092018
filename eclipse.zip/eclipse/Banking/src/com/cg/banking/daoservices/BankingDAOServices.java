package com.cg.banking.daoservices;

import com.cg.banking.beans.Customer;

public class BankingDAOServices {
	private static Customer []customerList = new Customer[10];
	private int CUSTOMER_ID_COUNTER=1;
	int insertCustomer(Customer customer) {
		customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		customer.getCustomerId()
		return 0;
	}
	boolean updateCustomer(Customer customer) {
		return true;
	}
	boolean deleteCustomer(int customerId) {
		return false;
	}
	Customer getCustomer(int customerId) {
		return null;
	}
	Customer[] getCustomers() {
		return null;
	}
}
