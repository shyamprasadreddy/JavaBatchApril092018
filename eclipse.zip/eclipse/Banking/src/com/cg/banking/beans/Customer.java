package com.cg.banking.beans;

public class Customer {
	private int customerId,mobileNo,adharNo;
	public String firstName,lastName,pancard,emailId,dateOfBirth;
	private Address address;
	private Account []accounts;
	Customer(){}
	public Customer(int customerId, int mobileNo, int adharNo, String firstName, String lastName, String pancard,
			String emailId, String dateOfBirth, Address address, Account[] accounts) {
		super();
		this.customerId = customerId;
		this.mobileNo = mobileNo;
		this.adharNo = adharNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.pancard = pancard;
		this.emailId = emailId;
		this.dateOfBirth = dateOfBirth;
		this.address = address;
		this.accounts = accounts;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getAdharNo() {
		return adharNo;
	}
	public void setAdharNo(int adharNo) {
		this.adharNo = adharNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPancard() {
		return pancard;
	}
	public void setPancard(String pancard) {
		this.pancard = pancard;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Account[] getAccounts() {
		return accounts;
	}
	public void setAccounts(Account[] accounts) {
		this.accounts = accounts;
	}
	
}
