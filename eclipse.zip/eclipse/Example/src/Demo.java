import java.io.IOException;

public class Demo {
	
	//	@SuppressWarnings("finally")
		static int test(){
			try {
				if(true)
					throw new IOException();
				return 10;
			} 
			catch (Exception e) {
				System.exit(0);
				return 15;
			}
			finally{
				return 100;
			}
		}
		public static void main(String[] args){
			System.out.println(test());
		}
	}


