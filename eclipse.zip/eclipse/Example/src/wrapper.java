import java.util.ArrayList;

public class wrapper {

	public static void main(String[] args) {
		//int num=100;
		//nteger iob=num;
		//System.out.println(iob);
		ArrayList<Integer> list=new ArrayList<Integer>();
		list.add(100);
		list.add(200);

		//for(Integer obj:list)
		
		for(ArrayList<Integer> obj:list)
			Integer obj=new Integer(obj);
			for()
		    System.out.println(obj); 

		
		
	}

}
