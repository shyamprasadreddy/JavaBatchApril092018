package com.cg.RailwayReservation.servrices;

public interface RailwayServices {

	
	
		
}
