package com.cg.RailwayReservation.daoservices;

import com.cg.RailwayReservation.beans.JourneyDetails;
import com.cg.RailwayReservation.beans.Passenger;

public interface RailwayDAOServices {

	  int  insertPassenger(Passenger passenger);
	  int insertJourneyDetails(int mobileNo,JourneyDetails journeydetails); 
	
	
}
