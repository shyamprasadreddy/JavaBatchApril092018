package com.cg.RailwayReservation.beans;

public class Passenger {
	private String name,gender;
	private int mobileNo,age;
	public Passenger(String name, String gender, int mobileNo, int age) {
		super();
		this.name = name;
		this.gender = gender;
		this.mobileNo = mobileNo;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	
	

}
