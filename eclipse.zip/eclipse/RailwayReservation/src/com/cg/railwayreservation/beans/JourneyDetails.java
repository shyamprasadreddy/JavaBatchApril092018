package com.cg.RailwayReservation.beans;

public class JourneyDetails {
	private String source,destination,boardingTime,arrivalTime,typeOfCoach,departuredate,arrivaldate;
	private int seatNo;

	public JourneyDetails(String source, String destination, String boardingTime, String arrivalTime,
			String typeOfCoach,int seatNo,String departuredate,String arrivaldate) {
		super();
		this.source = source;
		this.destination = destination;
		this.boardingTime = boardingTime;
		this.arrivalTime = arrivalTime;
		this.typeOfCoach = typeOfCoach;
		this.seatNo = seatNo;
		this.arrivaldate=arrivaldate;
		this.departuredate=departuredate;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getBoardingTime() {
		return boardingTime;
	}

	public void setBoardingTime(String boardingTime) {
		this.boardingTime = boardingTime;
	}

	public String getArrivalTime() {
		return arrivalTime;
	}

	public void setArrivalTime(String arrivalTime) {
		this.arrivalTime = arrivalTime;
	}

	public String getTypeOfCoach() {
		return typeOfCoach;
	}

	public void setTypeOfCoach(String typeOfCoach) {
		this.typeOfCoach = typeOfCoach;
	}

	public int getSeatNo() {
		return seatNo;
	}

	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}

	public String getDeparturedate() {
		return departuredate;
	}

	public void setDeparturedate(String departuredate) {
		this.departuredate = departuredate;
	}

	public String getArrivaldate() {
		return arrivaldate;
	}

	public void setArrivaldate(String arrivaldate) {
		this.arrivaldate = arrivaldate;
	}
	
	

}
