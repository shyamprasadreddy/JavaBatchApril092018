package com.cg.project.view;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.UserBean;




@WebServlet("/SuccessServlet")
public class SuccessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public void init(ServletConfig config) throws ServletException {
	}


	public void destroy() {
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		UserBean userBean=(UserBean) request.getAttribute("userBean");
		out.println("<html>");
		out.println("<body>");
		out.println("<div align='center'><font color='green'>"+userBean.getUserName()+"<div align='center'><font color='green'>"+userBean.getPassword());
		out.println("</html>");
		out.println("</body>");
	}

}
