package com.cg.threading.customer;

public class Customer {

}
