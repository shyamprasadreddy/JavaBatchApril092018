package com.cg.threading.main;

import com.cg.threading.threads.MyThread;
import com.cg.threading.threads.MyThreadSwitch;
import com.cg.threading.threads.RunnableResource;

public class MainClass {

	public static void main(String[] args) throws InterruptedException {
		RunnableResource r=new RunnableResource();
		Thread th1=new Thread(r, "th-1");
		Thread th2=new Thread(r, "th-2");
			
			th2.start();
			//th2.join(1);
	
			th1.start();

	}

}
