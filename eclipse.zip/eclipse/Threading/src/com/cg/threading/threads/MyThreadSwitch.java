package com.cg.threading.threads;

public class MyThreadSwitch extends Thread{

	public MyThreadSwitch() {
		super();

	}

	public MyThreadSwitch(String name) {
		super(name);

	}

	@Override
	public void run() {
		Thread t=Thread.currentThread();

		switch (t.getName()) {
		case "th-1":
			for (int i = 0; i < 100; i++)
				if(i%2==0) {
					//System.out.println("Even Number");
					System.out.println("Even Number"+i);
				}
			break;
		case "th-2":
			for (int i = 0; i < 100; i++)
				if(i%2!=0) {
					//System.out.println("Odd Numbers");
					System.out.println("Odd Number"+i);
				}
		default:
			break;
		}

	}

}
