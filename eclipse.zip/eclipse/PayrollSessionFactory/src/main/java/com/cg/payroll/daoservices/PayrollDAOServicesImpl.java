package com.cg.payroll.daoservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.PayrollServicesDownException;

//import com.cg.payroll.utility.PayrollUtility;
@Component("daoServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	@Autowired
	private SessionFactory sessionFactory;

	@Override
	public int insertAssociate(Associate associate)  {
		Session session = sessionFactory.openSession();
		Transaction tx = null;
		Integer associateId = null;

		try {
			tx = session.beginTransaction();
			associateId = (Integer) session.save(associate); 
			tx.commit();
		} catch (HibernateException e) {
			if (tx!=null) tx.rollback();
			e.printStackTrace(); 
		} finally {
			session.close(); 
		}
		return associateId;

	}

	@Override
	public boolean updateAssociate(Associate associate) {
		Session session = sessionFactory.openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction(); 
			session.update(associate); 
			tx.commit();
		} catch (HibernateException e) {
			if (tx!=null) tx.rollback();
			e.printStackTrace(); 
		} finally {
			session.close(); 
		}
		return true;

	}

	@Override
	public boolean deleteAssociate(int associateId) {

		Session session = sessionFactory.openSession();
		Transaction tx = null;

		try {
			tx = session.beginTransaction();
			Associate associate=(Associate) session.get(Associate.class, associateId);
			session.delete(associate); 
			tx.commit();
		} catch (HibernateException e) {
			if (tx!=null) tx.rollback();
			e.printStackTrace(); 
		} finally {
			session.close(); 
		}		
		return true;
	}

	@Override
	public Associate getAssociate(int associateId)  {

		Associate associate=(Associate)sessionFactory.openSession().get(Associate.class, associateId);
		return associate;


	}

	@Override
	public List<Associate> getAssociates()  {
		Session session = sessionFactory.openSession();
		Query query=session.createQuery("from Associate");
		return query.list();
	

	}


}