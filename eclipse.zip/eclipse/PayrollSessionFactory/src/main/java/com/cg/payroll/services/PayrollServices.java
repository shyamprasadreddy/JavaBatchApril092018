package com.cg.payroll.services;
import java.sql.SQLException;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
public interface PayrollServices {
	int acceptAssociateDetails(String firstName, String lastName, String department, String designation, String pancard,
			String emailId, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf, int accountNumber,
			String bankName, String ifscCode) ;
	boolean updateAssociateDetails(String firstName, String lastName, String department, String designation, String pancard,
			String emailId, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf, int accountNumber,
			String bankName, String ifscCode) ;
	float calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException,PayrollServicesDownException;
	boolean doDeleteAssociate(int associateId) throws PayrollServicesDownException;
	Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException,PayrollServicesDownException;
	List<Associate> getAllAssociatesDetails() throws PayrollServicesDownException;
	
}