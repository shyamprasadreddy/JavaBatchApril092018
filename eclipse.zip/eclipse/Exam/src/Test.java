import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;


 import java.util.*;
	public class PQ {
 public static void main(String[] args) {
 PriorityQueue<String> pq = new PriorityQueue<String>();
 pq.add(�carrot�);
 pq.add(�apple�);
 pq.add(�banana�);
	System.out.println(pq.poll() +�:� + pq.peek());
 }
	 }

