package com.cg.AirReservation.beans;

public class Cancellation {
	private String LastDateForCancellation;
	private int amountrefunded;
	public Cancellation() {}
	public Cancellation(String lastDateForCancellation, int amountrefunded) {
		super();
		LastDateForCancellation = lastDateForCancellation;
		this.amountrefunded = amountrefunded;
	}
	public String getLastDateForCancellation() {
		return LastDateForCancellation;
	}
	public void setLastDateForCancellation(String lastDateForCancellation) {
		LastDateForCancellation = lastDateForCancellation;
	}
	public int getAmountrefunded() {
		return amountrefunded;
	}
	public void setAmountrefunded(int amountrefunded) {
		this.amountrefunded = amountrefunded;
	}
	

}
