package com.cg.AirReservation.beans;

public class Passenger {
	private String name;
	private int mobileNo,Aadhar;
	private TicketDetails[] ticketdetails;
	public Passenger() {}
	public Passenger(String name, int mobileNo, int aadhar, TicketDetails[] ticketdetails) {
		super();
		this.name = name;
		this.mobileNo = mobileNo;
		this.Aadhar = aadhar;
		this.ticketdetails = ticketdetails;
	}
	public TicketDetails[] getTicketdetails() {
		return ticketdetails;
	}
	public void setTicketdetails(TicketDetails[] ticketdetails) {
		this.ticketdetails = ticketdetails;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getAadhar() {
		return Aadhar;
	}
	public void setAadhar(int aadhar) {
		Aadhar = aadhar;
	}
	

}
