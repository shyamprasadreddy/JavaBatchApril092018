package com.cg.AirReservation.beans;

public class Transaction {
	private String TypeofTransaction,transactionstatus,transactiondate;
	private int transactionamount;
	public Transaction() {}
	public Transaction(String typeofTransaction, String transactionstatus, String transactiondate,
			int transactionamount) {
		super();
		TypeofTransaction = typeofTransaction;
		this.transactionstatus = transactionstatus;
		this.transactiondate = transactiondate;
		this.transactionamount = transactionamount;
	}
	public String getTypeofTransaction() {
		return TypeofTransaction;
	}
	public void setTypeofTransaction(String typeofTransaction) {
		TypeofTransaction = typeofTransaction;
	}
	public String getTransactionstatus() {
		return transactionstatus;
	}
	public void setTransactionstatus(String transactionstatus) {
		this.transactionstatus = transactionstatus;
	}
	public String getTransactiondate() {
		return transactiondate;
	}
	public void setTransactiondate(String transactiondate) {
		this.transactiondate = transactiondate;
	}
	public int getTransactionamount() {
		return transactionamount;
	}
	public void setTransactionamount(int transactionamount) {
		this.transactionamount = transactionamount;
	}

}
