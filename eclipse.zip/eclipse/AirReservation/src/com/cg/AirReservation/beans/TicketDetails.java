package com.cg.AirReservation.beans;

public class TicketDetails {
	private String TypeOfClass,BoardinggPoint,EndingPoint,StartingTime,ReachingTime;
	private int ticketNo;
	private Transaction transaction;
	private Cancellation cancellation;
	public TicketDetails() {}
	public TicketDetails(String typeOfClass, String boardinggPoint, String endingPoint, String startingTime,
			String reachingTime, int ticketNo, Transaction transaction, Cancellation cancellation) {
		super();
		TypeOfClass = typeOfClass;
		BoardinggPoint = boardinggPoint;
		EndingPoint = endingPoint;
		StartingTime = startingTime;
		ReachingTime = reachingTime;
		this.ticketNo = ticketNo;
		this.transaction = transaction;
		this.cancellation = cancellation;
	}
	public Transaction getTransaction() {
		return transaction;
	}
	public void setTransaction(Transaction transaction) {
		this.transaction = transaction;
	}
	public Cancellation getCancellation() {
		return cancellation;
	}
	public void setCancellation(Cancellation cancellation) {
		this.cancellation = cancellation;
	}
	public String getTypeOfClass() {
		return TypeOfClass;
	}
	public void setTypeOfClass(String typeOfClass) {
		TypeOfClass = typeOfClass;
	}
	public String getBoardinggPoint() {
		return BoardinggPoint;
	}
	public void setBoardinggPoint(String boardinggPoint) {
		BoardinggPoint = boardinggPoint;
	}
	public String getEndingPoint() {
		return EndingPoint;
	}
	public void setEndingPoint(String endingPoint) {
		EndingPoint = endingPoint;
	}
	public String getStartingTime() {
		return StartingTime;
	}
	public void setStartingTime(String startingTime) {
		StartingTime = startingTime;
	}
	public String getReachingTime() {
		return ReachingTime;
	}
	public void setReachingTime(String reachingTime) {
		ReachingTime = reachingTime;
	}
	public int getTicketNo() {
		return ticketNo;
	}
	public void setTicketNo(int ticketNo) {
		this.ticketNo = ticketNo;
	}

}
