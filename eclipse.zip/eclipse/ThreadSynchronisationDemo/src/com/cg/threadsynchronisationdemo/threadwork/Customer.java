package com.cg.threadsynchronisationdemo.threadwork;

import com.cg.threadsynchronisationdemo.beans.Account;

public class Customer implements Runnable{

	public Customer() {}
	private static Account account;
	static {
		account=new Account(10000);
		System.out.println("Initial Balance :"+account.getBalance()+
				"\n\n===============================");
	}
	@Override
	public void run() {
		Thread customerThread=Thread.currentThread();
		if (customerThread.getName().equals("shyam")) {
			for (int i = 1; i <= 10; i++) {
				try {
					Thread.sleep(0);
					System.out.println("\nShyam has call withdraw()"+i+"time balance = "+account.withdraw(3000));
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

			}
		}
		else if (customerThread.getName().equals("prasad")) {
			for (int i = 1; i <=10; i++) {
				try {
					Thread.sleep(0);
					System.out.println("\nPrasad has call deposit()"+i+"time balance = "+account.deposit(3000));
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

			}
		}
		else if (customerThread.getName().equals("reddy")) {
			for (int i = 1; i < 4; i++) {
				try {
					Thread.sleep(0);
					System.out.println("\nReddy has call balance()"+"time balance = "+account.getBalance());
				} catch (InterruptedException e) {
					e.printStackTrace();
				}

			}
		}

	}

}
