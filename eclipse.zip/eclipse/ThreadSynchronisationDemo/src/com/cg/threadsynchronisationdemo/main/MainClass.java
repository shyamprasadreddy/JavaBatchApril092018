package com.cg.threadsynchronisationdemo.main;

import com.cg.threadsynchronisationdemo.threadwork.Customer;

public class MainClass {

	public static void main(String[] args) {
		Thread th1=new Thread(new Customer(), "shyam");
		Thread th2=new Thread(new Customer(), "prasad");
		Thread th3=new Thread(new Customer(), "reddy");
		th1.start();
		th2.start();
		th3.start();

	}

}
