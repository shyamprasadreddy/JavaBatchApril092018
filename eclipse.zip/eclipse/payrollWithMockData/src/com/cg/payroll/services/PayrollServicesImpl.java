package com.cg.payroll.services;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
public class PayrollServicesImpl implements PayrollServices {
	private PayrollDAOServicesImpl daoServices= new PayrollDAOServicesImpl();
	@Override
	public int acceptAssociateDetails(String firstName, String lastName,String department, String designation, 
			String pancard, String emailId,int yearlyInvestmentUnder80C,int basicSalary,int epf,int companyPf,int accountNumber,
			String bankName,String ifscCode) {
		return daoServices.insertAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
	}  
	@Override
	public boolean updateAssociateDetails(String firstName, String lastName,String department, String designation, 
			String pancard, String emailId,int yearlyInvestmentUnder80C,int basicSalary,int epf,int companyPf,int accountNumber,
			String bankName,String ifscCode) {
		return daoServices.updateAssociate(new Associate(yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode)));
	}
	@Override
	public float calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException,PayrollServicesDownException {
		if(getAssociateDetails(associateId)==null) throw new AssociateDetailsNotFoundException("Associate details not found");
		Associate associate=this.getAssociateDetails(associateId);
		if(associate!=null){
			associate.getSalary().setPersonalAllowance(0.3f*(associate.getSalary().getBasicSalary()));
			associate.getSalary().setConveyenceAllowance(0.2f*associate.getSalary().getBasicSalary());
			associate.getSalary().setOtherAllowance(0.1f*associate.getSalary().getBasicSalary());
			associate.getSalary().setHra(0.25f*associate.getSalary().getBasicSalary());
			float annualgrosssalary= associate.getSalary().getBasicSalary()+associate.getSalary().getPersonalAllowance()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getCompanyPf()+associate.getSalary().getHra();
			float annualtax;
			if(associate.getYearlyInvestmentUnder80C()>=(150000-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf())) {
				associate.setYearlyInvestmentUnder80C((int) (150000-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()));
			}
			else {
				associate.setYearlyInvestmentUnder80C(associate.getYearlyInvestmentUnder80C());
			}
			if(annualgrosssalary>0 &&annualgrosssalary<=250000) {
				annualtax= 0;
				associate.getSalary().setNetSalary(annualgrosssalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
				return associate.getSalary().getNetSalary();
			}
			else if(annualgrosssalary>250000&&annualgrosssalary<=500000) {
				annualtax= (annualgrosssalary-250000-associate.getYearlyInvestmentUnder80C()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf())*0.1f;
				associate.getSalary().setNetSalary(annualgrosssalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-annualtax);
				return associate.getSalary().getNetSalary();
			}
			else if(annualgrosssalary>500000&&annualgrosssalary<=1000000) {
				annualtax= ((250000-associate.getYearlyInvestmentUnder80C()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf())*0.1f+(annualgrosssalary-500000)*0.2f);
				associate.getSalary().setNetSalary(annualgrosssalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-annualtax);
				return associate.getSalary().getNetSalary();
			}
			else {
				annualtax= ((250000-associate.getYearlyInvestmentUnder80C()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf())*0.1f+500000*0.2f+(annualgrosssalary-1000000)*0.3f);
				associate.getSalary().setMonthlyTax(annualtax/12);
				associate.getSalary().setNetSalary(annualgrosssalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-annualtax);
				return associate.getSalary().getNetSalary();
			}
		}
		return 0;
	}
	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException,PayrollServicesDownException {
		Associate associate= daoServices.getAssociate(associateId);
		if(associate== null)
			throw new AssociateDetailsNotFoundException("Associate details not found");
		return daoServices.getAssociate(associateId);
	}
	public boolean doDeleteAssociate(int associateId) {
		return daoServices.deleteAssociate(associateId);
	}
	@Override
	public List<Associate> getAllAssociatesDetails() {
		return daoServices.getAssociates();
	}
}
