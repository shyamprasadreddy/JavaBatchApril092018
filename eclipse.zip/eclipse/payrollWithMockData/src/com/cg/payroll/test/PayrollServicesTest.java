package com.cg.payroll.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;


public class PayrollServicesTest {

	public static PayrollServicesImpl payrollservices;
	@BeforeClass
	public static void setUpTestEnv() {
		payrollservices=new PayrollServicesImpl();
	}
	@Before
	public  void setUpMockData() {
		PayrollUtility.ASSOCIATE_ID_COUNTER=111;
		Associate associate=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++,40000,"Shishir", "Reddy", "jr con", "training", "asdf123", "shishir@gmail.com", new Salary(600000, 12000, 12000), new BankDetails(1000,"HDFC", "HDFC1234"));
		Associate associate1=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++,150000,"asd", "fgfd", "jr con", "training", "asdfcvb123", "shishir@gmail.com", new Salary(120000, 10000, 1000), new BankDetails(1001,"HDFC", "HDFC1235"));
		Associate associate2=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++,10000,"gvdfb", "Recbddy", "jr con", "training", "ascvbdf123", "shishir@gmail.com", new Salary(100000, 20000, 1000), new BankDetails(1002,"HDFC", "HDFC1236"));
		PayrollDAOServicesImpl.associates.put(associate.getAssociateID(), associate);
		PayrollDAOServicesImpl.associates.put(associate1.getAssociateID(), associate1);
		PayrollDAOServicesImpl.associates.put(associate2.getAssociateID(), associate2);		

	}
	
	@Test
	public void testAssociateDetailsId() {
		//PayrollUtility.ASSOCIATE_ID_COUNTER=114;
		assertEquals(114, PayrollUtility.ASSOCIATE_ID_COUNTER);
	}

	
	@Test
	public void testAssociateWithValidDetails() throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		Associate actualAssociate= new Associate(111,40000,"Shishir", "Reddy", "jr con", "training", "asdf123", "shishir@gmail.com", new Salary(600000, 12000, 12000), new BankDetails(1000,"HDFC", "HDFC1234"));
		assertEquals(payrollservices.getAssociateDetails(111), actualAssociate);
	}
	
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testInvalidAssociatedetails() throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		Associate actualAssociate= new Associate(111,40000,"Shishir", "Reddy", "jr con", "training", "asdf123", "shishir@gmail.com", new Salary(150000, 100000, 1000), new BankDetails(1000,"HDFC", "HDFC1234"));
		assertEquals(payrollservices.getAssociateDetails(1234), actualAssociate);
	}
	
	@Test
	public void testNetSalary() throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		assertEquals(942800	, payrollservices.calculateNetSalary(111));
	}
	
	@Test
	public void testValidGetAssociateId() throws AssociateDetailsNotFoundException, PayrollServicesDownException {
		
		Associate associate=new Associate(120,400050,"Shigfshir", "Redghfdy", "jdgr con", "training", "asdbnf123", "shishir@gmail.com", new Salary(600000, 12000, 12000), new BankDetails(12000,"HDFC", "HDFC1254"));
		assertEquals(120, associate.getAssociateID());
	}
	
	
	
	
	@After
	public  void tearDownMockdata() {
	payrollservices.getAllAssociatesDetails().clear();
	PayrollUtility.ASSOCIATE_ID_COUNTER=111;
	}
	@AfterClass
	public static void tearDownTestEnv() {
		payrollservices=null;
	}
}
