package com.cg.LibraryManagement.beans;

public class User {
	private int mobileNo,userID;
	private String name;
	private Address address;
	private Book []books;
	public User() {
		// TODO Auto-generated constructor stub
	}
	public User(int mobileNo, int userID, String name, Address address, Book[] books) {
		super();
		this.mobileNo = mobileNo;
		this.userID = userID;
		this.name = name;
		this.address = address;
		this.books = books;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getUserID() {
		return userID;
	}
	public void setUserID(int userID) {
		this.userID = userID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Book[] getBooks() {
		return books;
	}
	public void setBooks(Book[] books) {
		this.books = books;
	}
	
}
