package com.cg.LibraryManagement.beans;

public class Issue {
	private String issueDate,issueFromDate,issueToDate,issuedTo,bookIssueStatus;
	private int issuedBookID,issueDuration;
	public Issue() {
		// TODO Auto-generated constructor stub
	}
	public Issue(String issueDate, String issueFromDate, String issueToDate, String issuedTo, String bookIssueStatus,
			int issuedBookID, int issueDuration) {
		super();
		this.issueDate = issueDate;
		this.issueFromDate = issueFromDate;
		this.issueToDate = issueToDate;
		this.issuedTo = issuedTo;
		this.bookIssueStatus = bookIssueStatus;
		this.issuedBookID = issuedBookID;
		this.issueDuration = issueDuration;
	}
	public String getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}
	public String getIssueFromDate() {
		return issueFromDate;
	}
	public void setIssueFromDate(String issueFromDate) {
		this.issueFromDate = issueFromDate;
	}
	public String getIssueToDate() {
		return issueToDate;
	}
	public void setIssueToDate(String issueToDate) {
		this.issueToDate = issueToDate;
	}
	public String getIssuedTo() {
		return issuedTo;
	}
	public void setIssuedTo(String issuedTo) {
		this.issuedTo = issuedTo;
	}
	public String getBookIssueStatus() {
		return bookIssueStatus;
	}
	public void setBookIssueStatus(String bookIssueStatus) {
		this.bookIssueStatus = bookIssueStatus;
	}
	public int getIssuedBookID() {
		return issuedBookID;
	}
	public void setIssuedBookID(int issuedBookID) {
		this.issuedBookID = issuedBookID;
	}
	public int getIssueDuration() {
		return issueDuration;
	}
	public void setIssueDuration(int issueDuration) {
		this.issueDuration = issueDuration;
	}
	
}
