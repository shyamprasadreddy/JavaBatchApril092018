package com.cg.LibraryManagement.beans;

public class Book {
	private String typeOfBook,bookName,bookAvailability;
	private int bookID,totNoOfBooks,NoOfBooksAva,NoOfBooksIssued;
	private Return []returns;
	private Penality []penalities;
	private Issue []issues;
	public Book() {
		// TODO Auto-generated constructor stub
	}
	public Book(String typeOfBook, String bookName, String bookAvailability, int bookID, int totNoOfBooks,
			int noOfBooksAva, int noOfBooksIssued, Return[] returns, Penality[] penalities, Issue[] issues) {
		super();
		this.typeOfBook = typeOfBook;
		this.bookName = bookName;
		this.bookAvailability = bookAvailability;
		this.bookID = bookID;
		this.totNoOfBooks = totNoOfBooks;
		NoOfBooksAva = noOfBooksAva;
		NoOfBooksIssued = noOfBooksIssued;
		this.returns = returns;
		this.penalities = penalities;
		this.issues = issues;
	}
	public String getTypeOfBook() {
		return typeOfBook;
	}
	public void setTypeOfBook(String typeOfBook) {
		this.typeOfBook = typeOfBook;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getBookAvailability() {
		return bookAvailability;
	}
	public void setBookAvailability(String bookAvailability) {
		this.bookAvailability = bookAvailability;
	}
	public int getBookID() {
		return bookID;
	}
	public void setBookID(int bookID) {
		this.bookID = bookID;
	}
	public int getTotNoOfBooks() {
		return totNoOfBooks;
	}
	public void setTotNoOfBooks(int totNoOfBooks) {
		this.totNoOfBooks = totNoOfBooks;
	}
	public int getNoOfBooksAva() {
		return NoOfBooksAva;
	}
	public void setNoOfBooksAva(int noOfBooksAva) {
		NoOfBooksAva = noOfBooksAva;
	}
	public int getNoOfBooksIssued() {
		return NoOfBooksIssued;
	}
	public void setNoOfBooksIssued(int noOfBooksIssued) {
		NoOfBooksIssued = noOfBooksIssued;
	}
	public Return[] getReturns() {
		return returns;
	}
	public void setReturns(Return[] returns) {
		this.returns = returns;
	}
	public Penality[] getPenalities() {
		return penalities;
	}
	public void setPenalities(Penality[] penalities) {
		this.penalities = penalities;
	}
	public Issue[] getIssues() {
		return issues;
	}
	public void setIssues(Issue[] issues) {
		this.issues = issues;
	}
	
}
