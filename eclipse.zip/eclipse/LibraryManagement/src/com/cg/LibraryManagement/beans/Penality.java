package com.cg.LibraryManagement.beans;

public class Penality {
	private String noOfDaysDelayed,penalityChargePerDay;
	private int penalityStatus;
	public Penality() {}
	public Penality(String noOfDaysDelayed, String penalityChargePerDay, int penalityStatus) {
		super();
		this.noOfDaysDelayed = noOfDaysDelayed;
		this.penalityChargePerDay = penalityChargePerDay;
		this.penalityStatus = penalityStatus;
	}
	public String getNoOfDaysDelayed() {
		return noOfDaysDelayed;
	}
	public void setNoOfDaysDelayed(String noOfDaysDelayed) {
		this.noOfDaysDelayed = noOfDaysDelayed;
	}
	public String getPenalityChargePerDay() {
		return penalityChargePerDay;
	}
	public void setPenalityChargePerDay(String penalityChargePerDay) {
		this.penalityChargePerDay = penalityChargePerDay;
	}
	public int getPenalityStatus() {
		return penalityStatus;
	}
	public void setPenalityStatus(int penalityStatus) {
		this.penalityStatus = penalityStatus;
	}
	
	
}
