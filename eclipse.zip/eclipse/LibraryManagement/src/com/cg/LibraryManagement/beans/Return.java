package com.cg.LibraryManagement.beans;

public class Return {
	private String dateOfReturn,returnStatus;
	private int returnedBookID;
	public Return() {
		// TODO Auto-generated constructor stub
	}
	public Return(String dateOfReturn, String returnStatus, int returnedBookID) {
		super();
		this.dateOfReturn = dateOfReturn;
		this.returnStatus = returnStatus;
		this.returnedBookID = returnedBookID;
	}
	public String getDateOfReturn() {
		return dateOfReturn;
	}
	public void setDateOfReturn(String dateOfReturn) {
		this.dateOfReturn = dateOfReturn;
	}
	public String getReturnStatus() {
		return returnStatus;
	}
	public void setReturnStatus(String returnStatus) {
		this.returnStatus = returnStatus;
	}
	public int getReturnedBookID() {
		return returnedBookID;
	}
	public void setReturnedBookID(int returnedBookID) {
		this.returnedBookID = returnedBookID;
	}
	
}
