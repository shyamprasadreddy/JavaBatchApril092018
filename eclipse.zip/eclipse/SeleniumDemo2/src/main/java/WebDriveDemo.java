import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebDriveDemo {

	public static void main(String[] args) {
		try {
		System.setProperty("webdriver.chrome.driver", "D:\\95344\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
		
		WebElement searchElement=driver.findElement(By.id("lst-ib"));
		searchElement.sendKeys("royal enfield 350 cc");
		searchElement.submit();
		
		WebElement imagesLink= driver.findElements(By.linkText("Images")).get(0);
		imagesLink.click();
		
		WebElement colorLink=driver.findElement(By.id("isr_chc"));
		colorLink.click();
		
		WebElement imageElement=driver.findElements(By.cssSelector("a[class=rg_l]")).get(0);
		
		WebElement imageLink=imageElement.findElements(By.tagName("img")).get(0);
		imageLink.click();
		
		} catch (Exception e) {
		 e.printStackTrace();
		}
	}

}
