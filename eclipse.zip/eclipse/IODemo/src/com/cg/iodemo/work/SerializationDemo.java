package com.cg.iodemo.work;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import com.cg.iodemo.beans.Associate;

public class SerializationDemo {
	public static void doSerialization(File file) throws IOException {
		Associate associate=new Associate(100,1000, "shyam", "prasad");
		try(ObjectOutputStream dest=new ObjectOutputStream(new FileOutputStream(file))){
			dest.writeObject(associate);
		}
		System.out.println("Associate details transfered"+ file.getAbsolutePath()+associate);
	
	}
	

	public static Object doDeSerialization(File file) throws FileNotFoundException, IOException, ClassNotFoundException {
		
		try(ObjectInputStream src=new ObjectInputStream(new FileInputStream(file))){
		return src.readObject();
			
		}
	}
	
}
