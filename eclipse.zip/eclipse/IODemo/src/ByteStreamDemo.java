import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;

import java.io.FileOutputStream;
import java.io.IOException;


public class ByteStreamDemo {

	public static void byteReadWriteWork(File fileFrom,File fileTo) throws IOException {
		try(BufferedInputStream src=new BufferedInputStream(new FileInputStream(fileFrom))) {
			try(BufferedOutputStream dest=new BufferedOutputStream(new FileOutputStream(fileTo))){

				//FileInputStream src=new FileInputStream(fileFrom);
				//	FileOutputStream dest=new FileOutputStream(fileTo);
				/*int a=0;
		while((a=src.read())!=-1) {

			System.out.print((char)a);
		}*/


				byte []bufferData =new byte[(int)fileFrom.length()];
				src.read(bufferData);
				dest.write(bufferData);
				dest.close();
				System.out.println(new String(bufferData));
			}
		}
	}
}
