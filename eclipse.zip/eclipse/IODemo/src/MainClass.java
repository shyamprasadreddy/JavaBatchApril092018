import java.io.File;
import java.io.IOException;

import com.cg.iodemo.beans.Associate;
import com.cg.iodemo.work.SerializationDemo;

public class MainClass {
	public static void main(String[] args){
		//File file=new  File("d:\\ShyamFile.txt");
		//SerializationDemo re=new SerializationDemo();
		try {
			File desfile=new File("d:\\Payroll.txt");
		SerializationDemo.doSerialization(desfile);
		System.out.println(SerializationDemo.doDeSerialization(desfile));
		//ByteStreamDemo.byteReadWriteWork(file, desfile);
		//System.out.println(file.canWrite());
		/*file.canRead();
		file.canWrite();
		
		
		
		if(!file.exists()) {
			file.createNewFile();		
			System.out.println(file.length());
			System.out.println(file.canRead());
			System.out.println(file.canWrite());
			//System.out.println(file.isFile());
		}
		else
			System.out.println(file.isFile());*/
		
		
		}	
		catch (Exception e) {
			e.printStackTrace();
		}

	}
}
