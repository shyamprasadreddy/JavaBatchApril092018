



import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.RegistrationPage;



public class RegistrationTest {
	static WebDriver driver;
	private RegistrationPage registrationPage;
	@BeforeClass
	public static void setUpDriverEnv(){
		System.setProperty("webdriver.chrome.driver","D:\\95344\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.manage().window().maximize();
	}
	@Before
	public void setUpTest(){
		driver.get("https://github.com/join?source=header-home");
		registrationPage=new RegistrationPage();
		PageFactory.initElements(driver, registrationPage);
	}
	@Test
	public void testForBlankUserNameAndPasswordAndEmailID(){
		registrationPage.setUsername("");
		registrationPage.setPassword("");
		registrationPage.setemailID("");
		registrationPage.clickSubmitButton();

		String actualErrorMessages=driver.findElement(By.xpath("//div[@class='flash flash-error my-3']")).getText();
		String expectedErrorMessage="There were problems creating your account.";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessages);
	}
	@Test
	public void testForBlankUserNameAndPasswordAndcorrectEmailID(){
		registrationPage.setUsername("");
		registrationPage.setPassword("");
		registrationPage.setemailID("divya@abc.com");
		registrationPage.clickSubmitButton();

		String actualErrorMessages=driver.findElement(By.xpath("//div[@class='flash flash-error my-3']")).getText();
		String expectedErrorMessage="There were problems creating your account.";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessages);
	}
	@Test
	public void testForBlankUserNameAndemailIDAndvalidPassword(){
		registrationPage.setUsername("");
		registrationPage.setPassword("Sweety67");
		registrationPage.setemailID("");
		registrationPage.clickSubmitButton();

		String actualErrorMessages=driver.findElement(By.xpath("//div[@class='flash flash-error my-3']")).getText();
		String expectedErrorMessage="There were problems creating your account.";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessages);
	}
	@Test
	public void testForValidUserNameAndBlankEmailIDAndPassword(){
		registrationPage.setUsername("Divya");
		registrationPage.setPassword("");
		registrationPage.setemailID("");
		registrationPage.clickSubmitButton();

		String actualErrorMessages=driver.findElement(By.xpath("//div[@class='flash flash-error my-3']")).getText();
		String expectedErrorMessage="There were problems creating your account.";
		Assert.assertEquals(expectedErrorMessage, actualErrorMessages);
	}
	@Test
	public void testForValidUserNameAndEmailIDAndPassword(){
		registrationPage.setUsername("shyamprasa");
		registrationPage.setPassword("Sweety67");
		registrationPage.setemailID("divya@abac.com");
		registrationPage.clickSubmitButton();

		String actualMessage=driver.findElement(By.name("user-login" )).getAttribute("content");		
					 String expectedMessage="shyamprasa";
					 Assert.assertEquals(expectedMessage, actualMessage);
	}



	@After
	public void setDownTest(){
		//registrationPage=null;
	}
	@AfterClass
	public static void setDownDriverEnv(){
	//	driver.close();
	}
}
