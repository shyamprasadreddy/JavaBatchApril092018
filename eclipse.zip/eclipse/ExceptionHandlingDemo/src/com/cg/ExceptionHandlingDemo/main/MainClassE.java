package com.cg.ExceptionHandlingDemo.main;

import java.util.InputMismatchException;
import java.util.Scanner;

public class MainClassE {
		public static void main(String []args) {
		
			Scanner scanner=new Scanner(System.in);
			try {
				
				System.out.println("Enter number");
				int n1=scanner.nextInt();
				System.out.println("Enter number");
				int n2=scanner.nextInt();
				System.out.println(n1/n2);
				System.out.println("Arithmetic task complete here");
				//in.close();
			}
			catch (InputMismatchException e) {
				e.printStackTrace();
				System.out.println("enter only integer");		
			}
			catch (ArithmeticException e) {
				e.printStackTrace();
				System.out.println("divide by zero or arithematic error");
			}
			System.out.println("after try catch");
		
		}
		
	}



