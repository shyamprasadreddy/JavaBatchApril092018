package com.cg.banking.daoservices;

public interface BankingDAOServices1 {

}
