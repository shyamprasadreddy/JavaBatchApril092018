package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Two")
public class Two extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	public void destroy() {
		// TODO Auto-generated method stub
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		out.println("<html>");
		out.println("<body>");
		out.println("<div align='center'>");
		out.println("Page2");
		out.println("<form name='Two' action='Three' method='post'>");

		out.println("<table>");
		out.println("<tr>");
		out.println("<td>firstName:</td>");
		out.print("<td>");
		out.print(firstName);
		out.print("</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>lastName:</td>");
		out.print("<td>");
		out.print(lastName);
		out.print("</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>city:</td>");
		out.println("<td><input type='text' size=25 name='city'></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>state:</td>");
		out.println("<td><input type='text' size=25 name='state'></td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td><input type='submit' value='enter'></td>");
		out.println("</tr>");
		out.println("</table>");
		out.println("</form>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");	}

}
