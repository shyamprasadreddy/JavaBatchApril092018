package com.cg.project.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Four")
public class Four extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	public void destroy() {
		// TODO Auto-generated method stub
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String city=request.getParameter("city");
		String state=request.getParameter("state");
		String phone=request.getParameter("phone");
		String email=request.getParameter("email");
		
		out.println("<html>");
		out.println("<body>");
		out.println("<div align='center'>");
		out.println("Page4");
		out.println("<table>");

		out.println("<tr><td>firstName:</td>");
		out.print("<td>");
		out.print(firstName);
		out.print("</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>lastName:</td>");
		out.print("<td>");
		out.print(lastName);
		out.print("</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>city:</td>");
		out.print("<td>");
		out.print(city);
		out.print("</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>state:</td>");
		out.print("<td>");
		out.print(state);
		out.print("</td>");
		out.println("</tr>");
		
		out.println("<tr>");
		out.println("<td>phone:</td>");
		out.print("<td>");
		out.print(phone);
		out.print("</td>");
		out.println("</tr>");
		out.println("<tr>");
		out.println("<td>email:</td>");
		out.print("<td>");
		out.print(email);
		out.print("</td>");
		out.println("</tr>");
		
		
		out.println("</table>");
		out.println("</form>");
		out.println("</div>");
		out.println("</body>");
		out.println("</html>");	}

}
