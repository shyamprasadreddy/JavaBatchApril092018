package com.cg.mobilebilling.beans;

public class Plan {
	private int planID, monthlyRental, freeLocalCalls, freeStdCalls, freeLocalSMS, freeStdSMS, Units;
	private String 	freeInternetDataUsage,planCircle, planName;
	private Float localCallRate, stdCallRate, localSMSRate, stdSMSRate, internetDataUsageRate;
	public Plan(int planID, int monthlyRental, int freeLocalCalls, int freeStdCalls, int freeLocalSMS, int freeStdSMS,
			int units, String freeInternetDataUsage, String planCircle, String planName, Float localCallRate,
			Float stdCallRate, Float localSMSRate, Float stdSMSRate, Float internetDataUsageRate) {
		super();
		this.planID = planID;
		this.monthlyRental = monthlyRental;
		this.freeLocalCalls = freeLocalCalls;
		this.freeStdCalls = freeStdCalls;
		this.freeLocalSMS = freeLocalSMS;
		this.freeStdSMS = freeStdSMS;
		Units = units;
		this.freeInternetDataUsage = freeInternetDataUsage;
		this.planCircle = planCircle;
		this.planName = planName;
		this.localCallRate = localCallRate;
		this.stdCallRate = stdCallRate;
		this.localSMSRate = localSMSRate;
		this.stdSMSRate = stdSMSRate;
		this.internetDataUsageRate = internetDataUsageRate;
	}
	public int getPlanID() {
		return planID;
	}
	public void setPlanID(int planID) {
		this.planID = planID;
	}
	public int getMonthlyRental() {
		return monthlyRental;
	}
	public void setMonthlyRental(int monthlyRental) {
		this.monthlyRental = monthlyRental;
	}
	public int getFreeLocalCalls() {
		return freeLocalCalls;
	}
	public void setFreeLocalCalls(int freeLocalCalls) {
		this.freeLocalCalls = freeLocalCalls;
	}
	public int getFreeStdCalls() {
		return freeStdCalls;
	}
	public void setFreeStdCalls(int freeStdCalls) {
		this.freeStdCalls = freeStdCalls;
	}
	public int getFreeLocalSMS() {
		return freeLocalSMS;
	}
	public void setFreeLocalSMS(int freeLocalSMS) {
		this.freeLocalSMS = freeLocalSMS;
	}
	public int getFreeStdSMS() {
		return freeStdSMS;
	}
	public void setFreeStdSMS(int freeStdSMS) {
		this.freeStdSMS = freeStdSMS;
	}
	public int getUnits() {
		return Units;
	}
	public void setUnits(int units) {
		Units = units;
	}
	public String getFreeInternetDataUsage() {
		return freeInternetDataUsage;
	}
	public void setFreeInternetDataUsage(String freeInternetDataUsage) {
		this.freeInternetDataUsage = freeInternetDataUsage;
	}
	public String getPlanCircle() {
		return planCircle;
	}
	public void setPlanCircle(String planCircle) {
		this.planCircle = planCircle;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public Float getLocalCallRate() {
		return localCallRate;
	}
	public void setLocalCallRate(Float localCallRate) {
		this.localCallRate = localCallRate;
	}
	public Float getStdCallRate() {
		return stdCallRate;
	}
	public void setStdCallRate(Float stdCallRate) {
		this.stdCallRate = stdCallRate;
	}
	public Float getLocalSMSRate() {
		return localSMSRate;
	}
	public void setLocalSMSRate(Float localSMSRate) {
		this.localSMSRate = localSMSRate;
	}
	public Float getStdSMSRate() {
		return stdSMSRate;
	}
	public void setStdSMSRate(Float stdSMSRate) {
		this.stdSMSRate = stdSMSRate;
	}
	public Float getInternetDataUsageRate() {
		return internetDataUsageRate;
	}
	public void setInternetDataUsageRate(Float internetDataUsageRate) {
		this.internetDataUsageRate = internetDataUsageRate;
	}
	

}
