package com.cg.mobilebilling.beans;

public class Bill {
	private int billId,billID, noOfLocalSMS ,noOfStdSMS,  noOfLocalCalls, noOfStdCalls, 	internetDataUsageUnits,internetDataUsageUnitsAmount;
	private String billMonth;
	private Float stateGST,centralGST,totalBillAmount, localSMSAmount, stdSMSAmount, localCallAmount;
	public Bill(int billId, int billID2, int noOfLocalSMS, int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls,
			int internetDataUsageUnits, int internetDataUsageUnitsAmount, String billMonth, Float stateGST,
			Float centralGST, Float totalBillAmount, Float localSMSAmount, Float stdSMSAmount, Float localCallAmount) {
		super();
		this.billId = billId;
		billID = billID2;
		this.noOfLocalSMS = noOfLocalSMS;
		this.noOfStdSMS = noOfStdSMS;
		this.noOfLocalCalls = noOfLocalCalls;
		this.noOfStdCalls = noOfStdCalls;
		this.internetDataUsageUnits = internetDataUsageUnits;
		this.internetDataUsageUnitsAmount = internetDataUsageUnitsAmount;
		this.billMonth = billMonth;
		this.stateGST = stateGST;
		this.centralGST = centralGST;
		this.totalBillAmount = totalBillAmount;
		this.localSMSAmount = localSMSAmount;
		this.stdSMSAmount = stdSMSAmount;
		this.localCallAmount = localCallAmount;
	}
	public int getBillId() {
		return billId;
	}
	public void setBillId(int billId) {
		this.billId = billId;
	}
	public int getBillID() {
		return billID;
	}
	public void setBillID(int billID) {
		this.billID = billID;
	}
	public int getNoOfLocalSMS() {
		return noOfLocalSMS;
	}
	public void setNoOfLocalSMS(int noOfLocalSMS) {
		this.noOfLocalSMS = noOfLocalSMS;
	}
	public int getNoOfStdSMS() {
		return noOfStdSMS;
	}
	public void setNoOfStdSMS(int noOfStdSMS) {
		this.noOfStdSMS = noOfStdSMS;
	}
	public int getNoOfLocalCalls() {
		return noOfLocalCalls;
	}
	public void setNoOfLocalCalls(int noOfLocalCalls) {
		this.noOfLocalCalls = noOfLocalCalls;
	}
	public int getNoOfStdCalls() {
		return noOfStdCalls;
	}
	public void setNoOfStdCalls(int noOfStdCalls) {
		this.noOfStdCalls = noOfStdCalls;
	}
	public int getInternetDataUsageUnits() {
		return internetDataUsageUnits;
	}
	public void setInternetDataUsageUnits(int internetDataUsageUnits) {
		this.internetDataUsageUnits = internetDataUsageUnits;
	}
	public int getInternetDataUsageUnitsAmount() {
		return internetDataUsageUnitsAmount;
	}
	public void setInternetDataUsageUnitsAmount(int internetDataUsageUnitsAmount) {
		this.internetDataUsageUnitsAmount = internetDataUsageUnitsAmount;
	}
	public String getBillMonth() {
		return billMonth;
	}
	public void setBillMonth(String billMonth) {
		this.billMonth = billMonth;
	}
	public Float getStateGST() {
		return stateGST;
	}
	public void setStateGST(Float stateGST) {
		this.stateGST = stateGST;
	}
	public Float getCentralGST() {
		return centralGST;
	}
	public void setCentralGST(Float centralGST) {
		this.centralGST = centralGST;
	}
	public Float getTotalBillAmount() {
		return totalBillAmount;
	}
	public void setTotalBillAmount(Float totalBillAmount) {
		this.totalBillAmount = totalBillAmount;
	}
	public Float getLocalSMSAmount() {
		return localSMSAmount;
	}
	public void setLocalSMSAmount(Float localSMSAmount) {
		this.localSMSAmount = localSMSAmount;
	}
	public Float getStdSMSAmount() {
		return stdSMSAmount;
	}
	public void setStdSMSAmount(Float stdSMSAmount) {
		this.stdSMSAmount = stdSMSAmount;
	}
	public Float getLocalCallAmount() {
		return localCallAmount;
	}
	public void setLocalCallAmount(Float localCallAmount) {
		this.localCallAmount = localCallAmount;
	}
	
}
