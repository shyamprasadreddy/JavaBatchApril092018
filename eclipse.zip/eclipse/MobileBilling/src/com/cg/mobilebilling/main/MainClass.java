package com.cg.mobilebilling.main;


import com.cg.mobilebilling.beans.Customer;

public class MainClass {

	public static void main(String[] args) {
		//Customer customer = new Customer(123456, 84998729, 12345678, "SUSHMA", "Bekkam", "abcd1234", "abcd@gmail.com", "07-04-1996");
				//System.out.println(customer.getCustomerId()+" "+customer.getFirstName());
	}

}
