package com.cg.project.services;

import org.springframework.stereotype.Component;


public class GreetingServicesNewImpl implements GreetingServices{
	
	
	
	
	@Override
	public void SayHello(String PersonName) {
		System.out.println("Hello New  "+PersonName);
	}

	@Override
	public void SayGoodBye(String PersonName) {
		System.out.println("Goodbye New  "+PersonName);

	}

}
