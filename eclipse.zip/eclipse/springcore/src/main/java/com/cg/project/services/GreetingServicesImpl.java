package com.cg.project.services;

import org.springframework.stereotype.Component;

@Component("greetingServices")
public class GreetingServicesImpl implements GreetingServices {
	public GreetingServicesImpl() {
	}
	@Override
	public void SayHello(String PersonName) {
		System.out.println("Hello  " + PersonName);		
	}

	@Override
	public void SayGoodBye(String PersonName) {
		System.out.println("GoodBye  " + PersonName);		

	}

}
