package com.cg.project.services;

public interface GreetingServices {

	
		public void SayHello(String PersonName);
		public void SayGoodBye(String PersonName);
}
