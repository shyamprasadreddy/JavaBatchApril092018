
package com.cg.payroll.main;
import java.util.List;
import java.util.Scanner;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.daoservices.PayrollDAOServices;

import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {
	public static void main(String[] args) throws PayrollServicesDownException,AssociateDetailsNotFoundException {
		//PayrollServicesImpl payrollservices=new PayrollServicesImpl();

		
		PayrollServicesImpl payrollServices = new PayrollServicesImpl(); 
		//Given annual basic salary
		int associateId=payrollServices.acceptAssociateDetails("shyam", "prasad", "asdf", "asd", "asd45", "zxcv@gm.com",40000,600000,12000, 12000, 12345, "hdfc", "asdf2");
		System.out.println(associateId);
		System.out.println(payrollServices.getAssociateDetails(associateId).getFirstName());
		System.out.println("Annual Net salary:" + payrollServices.calculateNetSalary(associateId));
		System.out.println("Monthly Tax:" + payrollServices.getAssociateDetails(associateId).getSalary().getMonthlyTax());

		
		
		
		
		
		/*int associateID;
		int key=0;
		while(key!=6){
			try {				
				Scanner sc=new Scanner(System.in);				
				System.out.print("Enter 1 : Insert New employee"+"\n"+"2 : To get Associate Details of employee"+"\n"+
						"3 : To get  All Associate Details of employee/"+"\n"+"4 : To Calculate salary of employee"+"\n"+
						"5 : To delete an employee"+"\n"+"6 : Exit");
				key=sc.nextInt();
				switch (key) {
				case 1:

					/*System.out.println("Enter customer details");
					System.out.println("Enter First Name");
					String firstName=scanner.next();
					System.out.println("Enter Last Name");
					String lastName=scanner.next();
					System.out.println("Enter emailId");
					String emailId=scanner.next();
					System.out.println("Enter panCard");
					String panCard=scanner.next();
					System.out.println("Enter LocalAddressCity");
					String localAddressCity=scanner.next();
					System.out.println("Enter LocalAddressState");
					String localAddressState=scanner.next();
					System.out.println("Enter LocalAddresspinCode");
					int localAddressPinCode=scanner.nextInt();
					System.out.println("Enter HomeAddresscity");
					String homeAddressCity=scanner.next();
					System.out.println("Enter HomeAddressState");
					String homeAddressState=scanner.next();
					System.out.println("Enter  homeAddressPinCode");
					int  homeAddressPinCode=scanner.nextInt();
					customerId= bankingservices.acceptCustomerDetails(firstName, lastName, emailId, panCard, localAddressCity, localAddressState, localAddressPinCode, homeAddressCity, homeAddressState, homeAddressPinCode);
					System.out.println("CustomerId is" + customerId






					associateID= payrollservices.acceptAssociateDetails("Shishir", "Reddy", "jr con", "training", "asdf123", "shishir@gmail.com", 150000, 100000, 1000, 1000, 123456, "HDFC", "HDFC1234");
					System.out.println(associateID);
					break;
				case 2: System.out.println("Enter the AssociateId of employee to get the Details");
				associateID=sc.nextInt();
				Associate associate2;
				associate2 = payrollservices.getAssociateDetails(associateID);
				System.out.println(associate2.toString());
				break;
				case 3: System.out.println("Following are the Employee details of Entire Array");
				List<Associate> associate=payrollservices.getAllAssociatesDetails();
				for(Associate associate1:associate)
					System.out.println(associate1);
				break;
				case 4: System.out.println("Enter the AssociateId of employee to calculate the salary");
				associateID=sc.nextInt();
				System.out.println(payrollservices.calculateNetSalary(associateID));
				break;
				case 5: System.out.println("Enter the AssociateId of employee to be deleted");
				associateID=sc.nextInt();
				System.out.println(payrollservices.doDeleteAssociate(associateID));
				case 6: System.out.println("Exit");
				break;
				default:
					break;
				}
			}

			catch (AssociateDetailsNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}*/
	}
}





