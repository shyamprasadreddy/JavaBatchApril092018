package com.cg.payroll.services;


import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServices;

import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;


@Component(value="services")
@Transactional
public class PayrollServicesImpl implements PayrollServices {
	@Autowired
	private PayrollDAOServices daoServices;



	@Override
	public int acceptAssociateDetails(Associate associate)  {
		return daoServices.save(associate).getAssociateID();
	}  
	@Override
	public boolean updateAssociateDetails(Associate associate)  {
		daoServices.saveAndFlush(associate) ;
		return true;
	}
	@Override
	public float calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException,PayrollServicesDownException {
		try {
			daoServices.findOne(associateId);
		} catch (Exception e) {

			e.printStackTrace();
			throw new PayrollServicesDownException("payroll service down");
		}
		if(getAssociateDetails(associateId)==null) throw new AssociateDetailsNotFoundException("Associate details not found");
		//Associate associate=this.getAssociateDetails(associateId);
		Associate associate=daoServices.findOne(associateId);
		if(associate!=null){
			associate.getSalary().setPersonalAllowance(0.3f*(associate.getSalary().getBasicSalary()));
			associate.getSalary().setConveyenceAllowance(0.2f*associate.getSalary().getBasicSalary());
			associate.getSalary().setOtherAllowance(0.1f*associate.getSalary().getBasicSalary());
			associate.getSalary().setHra(0.25f*associate.getSalary().getBasicSalary());
			float annualgrosssalary= associate.getSalary().getBasicSalary()+associate.getSalary().getPersonalAllowance()+associate.getSalary().getConveyenceAllowance()+associate.getSalary().getOtherAllowance()+associate.getSalary().getCompanyPf()+associate.getSalary().getHra();
			float annualtax;
			if(associate.getYearlyInvestmentUnder80C()>=(150000-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf())) {
				associate.setYearlyInvestmentUnder80C((int) (150000-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()));
			}
			else {
				associate.setYearlyInvestmentUnder80C(associate.getYearlyInvestmentUnder80C());
			}
			if(annualgrosssalary>0 &&annualgrosssalary<=250000) {
				annualtax= 0;
				associate.getSalary().setNetSalary(annualgrosssalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf());
				daoServices.saveAndFlush(associate);
				return associate.getSalary().getNetSalary();
			}
			else if(annualgrosssalary>250000&&annualgrosssalary<=500000) {
				annualtax= (annualgrosssalary-250000-associate.getYearlyInvestmentUnder80C()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf())*0.1f;
				associate.getSalary().setNetSalary(annualgrosssalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-annualtax);
				daoServices.saveAndFlush(associate);
				return associate.getSalary().getNetSalary();
			}
			/*else if(annualgrosssalary>500000&&annualgrosssalary<=1000000) {
				annualtax= ((250000-associate.getYearlyInvestmentUnder80C()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf())*0.1f+(annualgrosssalary-500000)*0.2f);
				associate.getSalary().setNetSalary(annualgrosssalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-annualtax);
				daoServices.findOne(associate);
				return associate.getSalary().getNetSalary();
			}*/
			else {
				annualtax= ((250000-associate.getYearlyInvestmentUnder80C()-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf())*0.1f+500000*0.2f+(annualgrosssalary-1000000)*0.3f);
				associate.getSalary().setMonthlyTax(annualtax/12);
				associate.getSalary().setNetSalary(annualgrosssalary-associate.getSalary().getEpf()-associate.getSalary().getCompanyPf()-annualtax);
				daoServices.saveAndFlush(associate);
				return associate.getSalary().getNetSalary();

			}

		}

		return 0;
	}
	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException,PayrollServicesDownException {


		if(daoServices.findOne(associateId)== null)
			throw new AssociateDetailsNotFoundException("Associate details not found");
		return daoServices.findOne(associateId);
	}
	public boolean doDeleteAssociate(int associateId) throws PayrollServicesDownException {
		//return false;
		try {
			 daoServices.delete(associateId);
			 return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw new PayrollServicesDownException("servicess down");
		}
	}
	@Override
	public List<Associate> getAllAssociatesDetails() throws PayrollServicesDownException {

		try {
			return daoServices.findAll();
		} catch (Exception e) {

			e.printStackTrace();
			throw new PayrollServicesDownException("services down");
		}
	}




}
