package com.cg.payroll.controller;

import java.sql.SQLException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;

public class LoginController {


	@Autowired
	PayrollServices payrollServices;

	@RequestMapping(value="/authUser")
	public String loginUser(@Valid@ModelAttribute("associate")Associate associate,BindingResult result) throws AssociateDetailsNotFoundException, SQLException{


		try{	
			if(result.hasFieldErrors("associateID")||result.hasFieldErrors("firstName")) 
				return "loginPage";
			//payrollServices.getAssociateDetails(associate.getAssociateID());
			//payrollServices.calculateNetSalary(associate.getAssociateID());
			if(associate.getFirstName().equals(payrollServices.getAssociateDetails(associate.getAssociateID()).getFirstName()))
				return "salaryPage";
			return "errorPage";
		}catch(Exception e ){
			return "errorPage";

		} 


	}
}
