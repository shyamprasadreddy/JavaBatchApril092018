package com.cg.OnlineExam.beans;

public class ExamDetails {
	private String date,time,location;
	private int examFee,duration;
	
}
