package com.cg.OnlineExam.beans;

public class Examinee {
	private String name,qualification,gender,emailId;
	private int regId,mobileNo,age;
	public Examinee() {
		// TODO Auto-generated constructor stub
	}
	public Examinee(String name, String qualification, String gender, String emailId, int regId, int mobileNo,
			int age) {
		super();
		this.name = name;
		this.qualification = qualification;
		this.gender = gender;
		this.emailId = emailId;
		this.regId = regId;
		this.mobileNo = mobileNo;
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public int getRegId() {
		return regId;
	}
	public void setRegId(int regId) {
		this.regId = regId;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
}
