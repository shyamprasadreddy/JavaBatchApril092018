package com.cg.payroll.daoservices;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.payroll.beans.Associate;

public interface PayrollDAOServices extends JpaRepository<Associate, Integer>{

//	void findOne(Associate associate);

	/*int insertAssociate(Associate associate) ;

	boolean updateAssociate(Associate associate) ;

	boolean deleteAssociate(int associateId) ;

	Associate getAssociate(int associateId) ;

	List<Associate> getAssociates() ;*/

}