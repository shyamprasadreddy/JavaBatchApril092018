package com.cg.payroll.utility;


import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;

public class AssociateMapper implements RowMapper<Associate>{
/*	   public Student mapRow(rs rs, int rowNum) throws SQLException {
		      Student student = new Student();
		      student.setId(rs.getInt("id"));
		      student.setName(rs.getString("name"));
		      student.setAge(rs.getInt("age"));
		      return student;
		   }*/
	@Override
	public Associate mapRow(ResultSet rs, int rowNo) throws SQLException {

		Associate associate=new Associate();
		associate.setAssociateID(rs.getInt("associateID"));
		associate.setYearlyInvestmentUnder80C(rs.getInt("yearlyInvestmentUnder80C"));
		associate.setFirstName(rs.getString("firstName"));
		associate.setLastName(rs.getString("lastName"));
		associate.setDepartment(rs.getString("department"));
		associate.setDesignation(rs.getString("designation"));
		associate.setPancard(rs.getString("pancard"));
		associate.setEmailId(rs.getString("emailId"));	
		
		BankDetails bankDetails=new BankDetails(rs.getInt("accountNumber"), rs.getString("bankName"), rs.getString("ifscCode"));
		associate.setBankDetails(bankDetails);
		Salary salary=new Salary(rs.getFloat("basicSalary"),rs.getFloat("hra"),rs.getFloat("conveyenceAllowance"),rs.getFloat("otherAllowance"),rs.getFloat("personalAllowance"),rs.getFloat("monthlyTax"),rs.getFloat("epf"),rs.getFloat("companyPf"),rs.getFloat("gratuity"),rs.getFloat("grossSalary"),rs.getFloat("netSalary"));
		associate.setSalary(salary);
		
		/*associate.getBankDetails().setAccountNumber(rs.getInt("accountNumber"));
		associate.getBankDetails().setBankName(rs.getString("bankName"));
		associate.getBankDetails().setIfscCode(rs.getString("ifscCode"));
		associate.getSalary().setBasicSalary(rs.getFloat("basicSalary"));
		associate.getSalary().setHra(rs.getFloat("hra"));
		associate.getSalary().setConveyenceAllowance(rs.getFloat("conveyenceAllowance"));
		associate.getSalary().setOtherAllowance(rs.getFloat("otherAllowance"));
		associate.getSalary().setPersonalAllowance(rs.getFloat("personalAllowance"));
		associate.getSalary().setMonthlyTax(rs.getFloat("monthlyTax"));
		associate.getSalary().setEpf(rs.getFloat("epf"));
		associate.getSalary().setCompanyPf(rs.getFloat("companyPf"));
		associate.getSalary().setGratuity(rs.getFloat("gratuity"));
		associate.getSalary().setGrossSalary(rs.getFloat("grossSalary"));
		associate.getSalary().setNetSalary(rs.getFloat("netSalary"));*/

		return associate;
	}

}
