
package com.cg.payroll.main;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.daoservices.PayrollDAOServices;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class MainClass {
	
	public static void main(String[] args) throws PayrollServicesDownException,AssociateDetailsNotFoundException, IOException, ClassNotFoundException, SQLException {
			
	int associateID ;
		int key=0;	
		while(key!=6){
			try {		
				ApplicationContext applicationContext=new ClassPathXmlApplicationContext("projectbeans.xml");				
				PayrollServices payrollservices=(PayrollServices) applicationContext.getBean("services");				
				Scanner scanner=new Scanner(System.in);		
				System.out.print("Enter "+ 
						"1 : Insert New employee"+"\n"+
						"2 : To get Associate Details of employee"+"\n"+
						"3 : To get  All Associate Details of employee/"+"\n"+
						"4 : To Calculate salary of employee"+"\n"+
						"5 : To delete an employee"+"\n"+"6 : Exit"+"\n"+
						"7: desrialise"
						);
				key=scanner.nextInt();				

				switch (key) {
				case 1:
					System.out.println("Enter Employee details");
					System.out.println("Enter yearlyInvestmentUnder80C");
					int yearlyInvestmentUnder80C=scanner.nextInt();
					System.out.println("Enter First Name");
					String firstName=scanner.next();
					System.out.println("Enter Last Name");
					String lastName=scanner.next();
					System.out.println("Enter department");
					String department=scanner.next();
					System.out.println("Enter designation");
					String designation=scanner.next();
					System.out.println("Enter pancard");
					String pancard=scanner.next();				
					System.out.println("Enter emailId");
					String emailId=scanner.next();
					System.out.println("Enter basicSalary");
					int basicSalary=scanner.nextInt();
					System.out.println("Enter epf");
					int epf=scanner.nextInt();
					System.out.println("Enter companyPf");
					int companyPf=scanner.nextInt();
					System.out.println("Enter  accountNumber");
					int  accountNumber=scanner.nextInt();
					System.out.println("Enter bankName");
					String bankName=scanner.next();
					System.out.println("Enter ifscCode");
					String ifscCode=scanner.next();
					associateID=payrollservices.acceptAssociateDetails(firstName, lastName, department, designation, pancard, emailId, yearlyInvestmentUnder80C, basicSalary, epf, companyPf, accountNumber, bankName, ifscCode);
					System.out.println("AssociateId is" + associateID);
					break;
				case 2: System.out.println("Enter the AssociateId of employee to get the Details");
				associateID=scanner.nextInt();
				Associate associate2;
				associate2 = payrollservices.getAssociateDetails(associateID);
				System.out.println(associate2.toString());
				break;
				case 3: System.out.println("Following are the Employee details of Entire Array");
				List<Associate> associate=payrollservices.getAllAssociatesDetails();
				for(Associate associate1:associate)
					System.out.println(associate1);
				break;
				case 4: System.out.println("Enter the AssociateId of employee to calculate the salary");
				associateID=scanner.nextInt();
				System.out.println(payrollservices.calculateNetSalary(associateID));
				break;
				case 5: System.out.println("Enter the AssociateId of employee to be deleted");
				associateID=scanner.nextInt();
				System.out.println(payrollservices.doDeleteAssociate(associateID));
				break;
				case 6: 					
					System.out.println("Exit");
					//payrollservices.doSerialization(file);
					break;
				default:
					break;
				}
			}
			catch (AssociateDetailsNotFoundException e) {
				e.printStackTrace();
			}
			catch (PayrollServicesDownException e) {
				e.printStackTrace();
			}
		}

		}
}






