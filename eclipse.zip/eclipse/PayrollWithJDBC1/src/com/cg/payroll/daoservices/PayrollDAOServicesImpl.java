package com.cg.payroll.daoservices;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.utility.AssociateMapper;
//import com.cg.payroll.utility.PayrollUtility;
@Component("daoServices")
public class PayrollDAOServicesImpl implements PayrollDAOServices {
	@Autowired
	JdbcTemplate jdbcTemplate;
	@Override
	public int insertAssociate(Associate associate) throws SQLException {		
		String sql="insert into Associate(yearlyInvestmentUnder80C,firstName,lastName,department,designation,pancard,emailId) value(?,?,?,?,?,?,?)";
		int associateId= jdbcTemplate.update(sql,new Object[] {associate.getYearlyInvestmentUnder80C(),associate.getFirstName(),associate.getLastName(),associate.getDepartment(),associate.getDesignation(),associate.getPancard(),associate.getEmailId()});
		String sql3 ="select max(associateID) from associate";
		int associateIDD=jdbcTemplate.queryForObject(sql3, Integer.class);
		String sql1="insert into Salary(associateID,basicSalary,epf,companyPf) value(?,?,?,?)";
		jdbcTemplate.update(sql1, new Object[] {associateIDD,associate.getSalary().getBasicSalary(),associate.getSalary().getEpf(),associate.getSalary().getCompanyPf()});
		String sql2="insert into BankDetails(associateID,accountNumber,bankName,ifscCode)value(?,?,?,?)";
		jdbcTemplate.update(sql2,new Object[] {associateIDD,associate.getBankDetails().getAccountNumber(),associate.getBankDetails().getBankName(),associate.getBankDetails().getIfscCode()});
		return associateId;
	}
	@Override
	public boolean updateAssociate(Associate associate) throws SQLException {

		String sql="update associate set  yearlyInvestmentUnder80C=?,firstName=?,lastName=?,department=?,designation=?,pancard=?,emailId=? where associateID=?";
		jdbcTemplate.update(sql,new Object[] {associate.getYearlyInvestmentUnder80C(),associate.getFirstName(),associate.getLastName(),associate.getDepartment(),associate.getDesignation(),associate.getPancard(),associate.getEmailId(),associate.getAssociateID()});

		String sql1="update salary set basicSalary=?,hra=?,conveyenceAllowance=?,otherAllowance=?,"
				+ "personalAllowance=?,monthlyTax=?,epf=?,companyPf=?,gratuity=?,grossSalary=?,"
				+ "netSalary=? where associateID=?";
		jdbcTemplate.update(sql1, new Object[] {associate.getSalary().getBasicSalary(),associate.getSalary().getHra(),associate.getSalary().getConveyenceAllowance(),associate.getSalary().getOtherAllowance(),associate.getSalary().getPersonalAllowance(),associate.getSalary().getMonthlyTax(),associate.getSalary().getEpf(),associate.getSalary().getCompanyPf(),associate.getSalary().getGratuity(),associate.getSalary().getGrossSalary(),associate.getSalary().getNetSalary(),associate.getAssociateID()});

		String sql2="update bankdetails set accountNumber=?,bankName=?,ifscCode=? where associateID=?";
		jdbcTemplate.update(sql2,new Object[] {associate.getBankDetails().getAccountNumber(),associate.getBankDetails().getBankName(),associate.getBankDetails().getIfscCode(),associate.getAssociateID()});

		return true;
	}
	@Override
	public boolean deleteAssociate(int associateId) throws SQLException {
		String sql="delete from associate where associateID=?";
		jdbcTemplate.update(sql, new Object[] {associateId});
		return true;
	}
	@Override
	public Associate getAssociate(int associateId) throws SQLException {
		String sql="SELECT   a.associateID,a.yearlyInvestmentUnder80C,a.firstName,a.lastName,a.department,a.designation,a.pancard,a.emailId,\r\n" + 
				"									b.basicSalary,b.hra,b.conveyenceAllowance,b.otherAllowance,b.personalAllowance,b.monthlyTax,b.epf,b.companyPf,b.gratuity,b.grossSalary,b.netSalary, \r\n" + 
				"									c.accountNumber,c.bankName,c.ifscCode\r\n" + 
				"								FROM	associate a INNER JOIN salary b INNER JOIN  bankdetails c \r\n" + 
				"								ON	a.associateID=b.associateID AND	a.associateID=c.associateID where a.associateID=?";
		Associate associate = (Associate)jdbcTemplate.queryForObject(sql, new Object[] {associateId},new AssociateMapper());




		return associate;
	}
	@Override
	public List<Associate> getAssociates() throws SQLException {
		/*String sql="SELECT   a.associateID,a.yearlyInvestmentUnder80C,a.firstName,a.lastName,a.department,a.designation,a.pancard,a.emailId,\r\n" + 
				"									b.basicSalary,b.hra,b.conveyenceAllowance,b.otherAllowance,b.personalAllowance,b.monthlyTax,b.epf,b.companyPf,b.gratuity,b.grossSalary,b.netSalary, \r\n" + 
				"									c.accountNumber,c.bankName,c.ifscCode\r\n" + 
				"								FROM	associate a INNER JOIN salary b INNER JOIN  bankdetails c \r\n" + 
				"								ON	a.associateID=b.associateID AND	a.associateID=c.associateID ";*/
		//List<Associate> associate = (List<Associate>)jdbcTemplate.queryForObject(sql,new AssociateMapper());
		@SuppressWarnings("unchecked")
		List<Associate> associate = jdbcTemplate.query(
				"SELECT * FROM associate", new BeanPropertyRowMapper(
						Associate.class));

		return associate;
	}

}