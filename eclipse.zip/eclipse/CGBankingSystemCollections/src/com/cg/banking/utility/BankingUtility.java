package com.cg.banking.utility;


public class BankingUtility {
	
	public static int CUSTOMER_ID_COUNTER=100,ACCOUNT_ID_COUNTER=111,TRANSACTION_ID_COUNTER=1;
	
}
