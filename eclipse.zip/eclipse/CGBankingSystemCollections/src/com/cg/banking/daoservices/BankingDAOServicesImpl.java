

package com.cg.banking.daoservices;


import java.util.List;



import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

@Component("daoservices")
public class BankingDAOServicesImpl implements BankingDAOServices{
	@Autowired
	private SessionFactory sessionFactory;
	private Session session;
	private org.hibernate.Transaction tx;
	@Override
	public int insertCustomer(Customer customer) {
		session = sessionFactory.openSession();
		tx = session.beginTransaction();


		try {
			int customerId = (Integer) session.save(customer); 
			tx.commit();
			return customerId;

		} catch (HibernateException e) {
			if (tx!=null) tx.rollback();
			e.printStackTrace(); 
			throw e;
		} finally {
			session.close(); 
		}
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		session=sessionFactory.openSession();
		tx=session.beginTransaction();
	
		try {
			
			Customer customer=getCustomer(customerId); 
			account.setCustomer(customer);
			long accountNo=(long) session.save(account);	
			tx.commit();
			return accountNo;
		} catch (HibernateException e) {
			if (tx!=null)tx.rollback(); {
				e.printStackTrace(); 
				throw e;
			}
		}
		finally {
			session.close();
		}
		
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		session=sessionFactory.openSession();
		tx=session.beginTransaction();
	try {
			
			Customer customer=getCustomer(customerId); 
			account.setCustomer(customer);
			session.update(account);	
			tx.commit();
			return true;
		} catch (HibernateException e) {
			if (tx!=null)tx.rollback(); {
				e.printStackTrace(); 
				throw e;
			}
		}
		finally {
			session.close();
		}

		
	}

	@Override
	public int generatePin(int customerId, Account account) {
		return 0;
	}
	
	@Override
	public boolean insertTransaction(int customerId,long accountNo,Transaction transaction) {
		session=sessionFactory.openSession();
		tx=session.beginTransaction();
	
		try {
			Account account=getAccount(customerId, accountNo);
			transaction.setAccount(account);
			session.save(transaction);	
			tx.commit();
			return true;
		} catch (HibernateException e) {
			if (tx!=null)tx.rollback(); {
				e.printStackTrace(); 
				throw e;
			}
		}
		finally {
			session.close();
		}
		
		
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		
		session=sessionFactory.openSession();
		tx=session.beginTransaction();
	try {			
			Customer customer=getCustomer(customerId); 			
			session.delete(customer);	
			tx.commit();
			return true;
		} catch (HibernateException e) {
			if (tx!=null)tx.rollback(); {
				e.printStackTrace(); 
				throw e;
			}
		}
		finally {
			session.close();
		}

	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		session=sessionFactory.openSession();
		tx=session.beginTransaction();
	try {			
			Account account=getAccount(customerId, accountNo);	
			session.delete(account);	
			session.flush();
			tx.commit();
			return true;
		} catch (HibernateException e) {
			if (tx!=null)tx.rollback(); {
				e.printStackTrace(); 
				throw e;
			}
		}
		finally {
			session.close();
		}
	}

	@Override
	public Customer getCustomer(int customerId) {
		session = sessionFactory.openSession();

		Customer customer=(Customer) sessionFactory.openSession().get(Customer.class, customerId);
		return customer;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {
		session = sessionFactory.openSession();

		Account account=(Account) sessionFactory.openSession().get(Account.class, accountNo);
		if(account.getCustomer().getCustomerId()==customerId)
		return account;
		else
			return null;
	}

	@Override
	public List<Customer> getCustomers() {
		session = sessionFactory.openSession();
		Query query=session.createQuery("from Customer");
		return query.list();
			
		
	}

	@Override
	public List<Account> getAccounts(int customerId) {
		return null;
	}

	@Override
	public List<com.cg.banking.beans.Transaction> getTransactions(int customerId, long accountNo) {
		return null;
	}


	
	
	
	
	
	
	
	
	
	
	
	
	
	/*public static HashMap<Integer, Customer> customers=new HashMap<>();
	@Override
	public int insertCustomer(Customer customer) {
		customer.setCustomerId(BankingUtility.CUSTOMER_ID_COUNTER++);
		customers.put(customer.getCustomerId(), customer);
		return  customer.getCustomerId();
	}

	@Override
	public long insertAccount(int customerId, Account account) {
		account.setAccountNo(BankingUtility.ACCOUNT_ID_COUNTER++);
		getCustomer(customerId).getAccounts().put(account.getAccountNo(), account);		
		account.setStatus("active");
		return account.getAccountNo();
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {
		getCustomer(customerId).getAccounts().put(account.getAccountNo(), account);	
		return true;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		Random random=new Random();
		account.setPinNumber(random.nextInt(10000));
		getCustomer(customerId).getAccounts().put(account.getAccountNo(), account);
		return account.getPinNumber();
		
	}

	@Override
	public boolean insertTransaction(int customerId, long accountNo, Transaction transaction) {
		transaction.setTransactionId(BankingUtility.TRANSACTION_ID_COUNTER++);
		if(getAccount(customerId, accountNo)!=null){
		getAccount(customerId, accountNo).getTransactions().put(transaction.getTransactionId(), transaction);
		return true;
		}
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		customers.remove(customerId);
		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {
		getCustomer(customerId).getAccounts().remove(accountNo);
		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		
		return customers.get(customerId);
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {

		return customers.get(customerId).getAccounts().get(accountNo);
	}

	@Override
	public List<Customer> getCustomers() {
		
		return new ArrayList<>(customers.values());
	}

	@Override
	public List<Account> getAccounts(int customerId) {

		return new ArrayList<>(customers.get(customerId).getAccounts().values());
	}

	@Override
	public List<Transaction> getTransactions(int customerId, long accountNo) {
		return new ArrayList<>(getAccount(customerId, accountNo).getTransactions().values());
		
	}
		*/
	

}
