package com.cg.project.collections;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import com.cg.project.bean.Customer;

public class ListClassDemo {

	public static void arrayListClassWork() {
		/*ArrayList<String> strList=new ArrayList<>();
		//insert
		strList.add("shyam");
		strList.add("prasad");
		strList.add("rasad");
		strList.add("asad");
		strList.add("qsad");
		strList.add("ad");
		Collections.sort(strList);
		//iterator
		Iterator<String> iterator=strList.iterator();
		while (iterator.hasNext()) {
			String string =iterator.next();

		//search
			System.out.println(strList.contains("prasad"));
			int idx=strList.indexOf("ad");*/

		ArrayList<Customer> customerList=new ArrayList<>();
		customerList.add(new Customer(111, "shyam", "prasad"));
		customerList.add(new Customer(112, "prasad", "reddy"));
		customerList.add(new Customer(113, "ashyam", "dprasad"));
		//Customer customerToBeSearch=new Customer(111, "prasad", "reddy");
		//System.out.println(customerList.contains(customerToBeSearch));
		Collections.sort(customerList);
		for (Customer customer : customerList) {
			System.out.println(customer);
		}
	}
}

