package com.cg.project.main;

import java.util.ArrayList;
import java.util.List;

public class MainClassGeneric {

	public static void main(String[] args) {

		ArrayList<String> strList= new ArrayList<>();
		strList.add("shyam");
		strList.add("prasad");
		iterateOnList(strList);

		ArrayList<Integer> intList=new ArrayList<>();
		intList.add(10);
		intList.add(20);
		iterateOnList(intList);

	}
	private static void iterateOnList(List<? extends Comparable<?>> elements) {
		for (Comparable<?> comparable : elements)
			System.out.println(comparable);
	}
}

