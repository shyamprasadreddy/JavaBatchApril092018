package com.cg.project.main;

import java.util.ArrayList;

import com.cg.project.collections.ListClassDemo;

public class MainClass {
	public static void main(String []args) {
		ListClassDemo.arrayListClassWork();
	}
}
