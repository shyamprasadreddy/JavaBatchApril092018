package com.cg.banking.main;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.daoservices.BankingDAOServicesImpl;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {
	public static void main(String[] args) {
		
		BankingServicesImpl bankingservices=new BankingServicesImpl();
		//Customer customer=new Customer();
		int customerId=bankingservices.acceptCustomerDetails("shyam", "prasad", "asd@aqs", "asd123", "hyd", "ts", 52042, "kurn", "ap", 1234);
		long accountNo=bankingservices.openAccount(customerId, "saving", 1000);
		long accountNo1=bankingservices.openAccount(customerId, "current", 2000);
		System.out.println(bankingservices.generateNewPin(customerId, accountNo));
		/*Account[] account=bankingservices.getcustomerAllAccountDetails(customerId);
		for (int i = 0; i < account.length; i++) {
			System.out.println(account[i].getAccountNo());
		}*/
	//	System.out.println(accountNo1);
	//	System.out.println(customerId);
//		//System.out.println(acc);
	//	System.out.println(bankingservices.getCustomerDetails(customerId).getFirstName());
	}
}
