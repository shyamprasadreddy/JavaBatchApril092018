package com.cg.banking.services;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.daoservices.BankingDAOServicesImpl;

public class BankingServicesImpl implements BankingServices {
	private BankingDAOServicesImpl daoservices=new BankingDAOServicesImpl();
	@Override
	public int acceptCustomerDetails(String firstName, String lastName, String emailId, String panCard,
			String localAddressCity, String localAddressState, int localAddressPinCode, String homeAddressCity,
			String homeAddressState, int homeAddressPinCode) {
			
		return daoservices.insertCustomer(new Customer(firstName, lastName, emailId, panCard,new Address(localAddressPinCode, localAddressCity, localAddressState),new Address(homeAddressPinCode, homeAddressCity, homeAddressState)));		
	}

	@Override
	public long openAccount(int customerId, String accountType, float accountBalance) {
		return daoservices.insertAccount(customerId, new Account(accountType, accountBalance));

	}

	@Override
	public float depositAmount(int customerId, long accountNo, float amount) {
		
		return daoservices.insertTransaction(customerId, accountNo, new Transaction(amount));
	}

	@Override
	public float withdrawAmount(int customerId, long accountNo, float amount, int pinNumber) {

		return daoservices.insertTransaction(customerId, accountNo, new Transaction(amount));
	}

	@Override
	public boolean fundTransfer(int customerIdTo, long accountNoTo, int customerIdFrom, long accountNoFrom,
			float transferAmount, int pinNumber) {
		
		return false;
	}

	@Override
	public Customer getCustomerDetails(int customerId) {

		return daoservices.getCustomer(customerId);
	}

	@Override
	public Account getAccountDetails(int customerId, long accountNo) {

		return daoservices.getAccount(customerId, accountNo);
	}

	@Override
	public int generateNewPin(int customerId, long accountNo) {
		Account account=daoservices.getAccount(customerId, accountNo);
		return daoservices.generatePin(customerId, account);
	}

	@Override
	public boolean changeAccountPin(int customerId, long accountNo, int oldPinNumber, int newPinNumber) {

		return false;
	}

	@Override
	public Customer[] getAllCustomerDetails() {

		return daoservices.getCustomers();
	}

	@Override
	public Account[] getcustomerAllAccountDetails(int customerId) {

		return daoservices.getAccounts(customerId);
	}

	@Override
	public Transaction[] getAccountAllTransaction(int customerId, long accountNo) {

		return null;
	}

	@Override
	public String accountStatus(int customerId, long accountNo) {

		return null;
	}
	
}
