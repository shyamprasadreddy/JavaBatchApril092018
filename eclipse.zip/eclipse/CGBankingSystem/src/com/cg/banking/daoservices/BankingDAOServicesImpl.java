package com.cg.banking.daoservices;

import java.util.Random;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;


public class BankingDAOServicesImpl implements BankingDAOServices {
	
	private static Customer []customerList=new Customer[10];
	private static int  CUSTOMER_ID_COUNTER=100,ACCOUNT_ID_COUNTER=111,TRANSACTION_ID_COUNTER=1;
	private static int  CUSTOMER_IDX=0;

	public int insertCustomer(Customer customer) {
		customer.setCustomerId(CUSTOMER_ID_COUNTER++);
		customerList[CUSTOMER_IDX++]=customer;
		return customer.getCustomerId();
	}
	public long insertAccount(int customerId,Account account) {
		for(int i=0;i<customerList.length;i++) 
			if(customerList[i]!=null &&customerList[i].getCustomerId()==customerId) {
				account.setAccountNo(ACCOUNT_ID_COUNTER++);
				customerList[i].getAccounts()[customerList[i].getACCOUNT_IDX()]=account;
				
				
				//customerList[i].getAccounts()[customerList[i].getACCOUNT_IDX()].setAccountNo(ACCOUNT_ID_COUNTER++);
				customerList[i].getAccounts()[customerList[i].getACCOUNT_IDX()].getAccountNo();
				customerList[i].setACCOUNT_IDX(customerList[i].getACCOUNT_IDX()+1);
				/*customerList[i].getAccounts()[account.getACCOUNT_IDX()]=account;
				account.setACCOUNT_IDX(account.getACCOUNT_IDX());
				customerLcist[i].getAccounts()[account.getACCOUNT_IDX()].setAccountNo(ACCOUNT_ID_COUNTER++);
				return customerList[i].getAccounts()[account.getACCOUNT_IDX()].getAccountNo();*/
				return account.getAccountNo();
			}
		return 0;
	}

	@Override
	public boolean updateAccount(int customerId, Account account) {

		for(int i=0;i<getCustomer(customerId).getAccounts().length;i++) 
			if(getCustomer(customerId).getAccounts()[i].getAccountNo()== account.getAccountNo()) {
				getCustomer(customerId).getAccounts()[i]=account;
				return true;
			}
		return false;
	}

	@Override
	public int generatePin(int customerId, Account account) {
		Random r=new Random();
		int nxt = r.nextInt(10000); 
		for(int i=0;i<getCustomer(customerId).getAccounts().length;i++) 
			if(getCustomer(customerId).getAccounts()[i].getAccountNo()==account.getAccountNo()) {
				getCustomer(customerId).getAccounts()[i].setPinNumber(nxt++);
				return getCustomer(customerId).getAccounts()[i].getPinNumber();
			}
		return 0;
	}

	@Override
	public int insertTransaction(int customerId, long accountNo, Transaction transaction) {
				
		for (int j = 0; j < customerList.length; j++) 
			if(getAccount(customerId, accountNo).getAccountNo()==accountNo) {
				transaction.setTransactionId(TRANSACTION_ID_COUNTER++);
				getAccount(customerId, accountNo).getTransactions()[getAccount(customerId, accountNo).getTRANSACTION_IDX_COUNTER()]=transaction;
				getAccount(customerId, accountNo).getTransactions()[getAccount(customerId, accountNo).getTRANSACTION_IDX_COUNTER()].getTransactionId();
				getAccount(customerId, accountNo).setTRANSACTION_IDX_COUNTER(getAccount(customerId, accountNo).getTRANSACTION_IDX_COUNTER()+1);
				return transaction.getTransactionId();
			}

		return 0;
	}

	@Override
	public boolean deleteCustomer(int customerId) {

		return false;
	}

	@Override
	public boolean deleteAccount(int customerId, long accountNo) {

		return false;
	}

	@Override
	public Customer getCustomer(int customerId) {
		//Customer customer=new Customer();
		for(int i=0;i<customerList.length;i++)
			if(customerList!=null&&customerList[i].getCustomerId()==customerId)
				return customerList[i];
		return null;
	}

	@Override
	public Account getAccount(int customerId, long accountNo) {		
		for(int i=0;i<getCustomer(customerId).getAccounts().length;i++)
		if(getCustomer(customerId).getAccounts()[i].getAccountNo()==accountNo) {
		return getCustomer(customerId).getAccounts()[i];
			}
		return null;
	}

	@Override
	public Customer[] getCustomers() {

		return customerList;
	}

	@Override
	public Account[] getAccounts(int customerId) {

		return getCustomer(customerId).getAccounts();
	}

	@Override
	public Transaction[] getTransactions(int customerId, long accountNo) {
		return getAccount(customerId, accountNo).getTransactions();
	
	}

}
