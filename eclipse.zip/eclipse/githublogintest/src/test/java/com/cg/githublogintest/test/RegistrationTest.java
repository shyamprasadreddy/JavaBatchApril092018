package com.cg.githublogintest.test;

import static org.junit.Assert.assertEquals;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.githublogintest.model.RegisterPage;

public class RegistrationTest {
	static WebDriver driver;
	private RegisterPage registerPage;
	
	@BeforeClass
	public static void setUpDriverEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\95344\\chromedriver.exe");	
		driver= new ChromeDriver();
		driver.manage().window().maximize();
	}
	@Before
	public void setUptestEnv() {
		driver.get("https://github.com/join?source=header-home");
		registerPage=new RegisterPage();
		PageFactory.initElements(driver, registerPage);
	}
	@Test
	public void testForBlankUserNameAndPasswordAndEmailID() {
		registerPage.setUsername("");
		registerPage.setPassword("");
		registerPage.setEmailID("");
		registerPage.clickSubmitButton();
		
		//WebElement formElement=driver.findElement(By.id("signup-form"));
		//String actualErrorMessage=formElement.findElement(By.tagName("div")).getText();
		String actualErrorMessage=driver.findElement(By.xpath(("//*[@id=\"signup-form\"]/div"))).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String message="There were problems creating your account.";
		assertEquals(actualErrorMessage, message);
		
		String userNameMsg=driver.findElement(By.xpath(("//*[@id=\"signup-form\"]/auto-check[1]/dl/dd[2]"))).getText();
		System.out.println("error UserName Message:-"+userNameMsg);
		String mesaage1="Login can't be blank";
		assertEquals(userNameMsg, mesaage1);
		
		String emailIDMsg=driver.findElement(By.xpath(("//*[@id=\"signup-form\"]/auto-check[2]/dl/dd[2]"))).getText();
		System.out.println("error UserName Message:-"+emailIDMsg);
		String mesaage2="Email can't be blank";
		assertEquals(emailIDMsg, mesaage2);
		
		String passwordMsg=driver.findElement(By.xpath(("//*[@id=\"signup-form\"]/auto-check[3]/dl/dd[2]"))).getText();
		System.out.println("error UserName Message:-"+passwordMsg);
		String mesaage3="Password can't be blank and is too short (minimum is 7 characters)";
		assertEquals(passwordMsg, mesaage3);
	}

	@Test
	public void testForInvalidUserNameAndPasswordAndEmailID() {
		registerPage.setUsername("achikoti");
		registerPage.setPassword("abhinav");
		registerPage.setEmailID("anskl@anfk.com");
		registerPage.clickSubmitButton();

		//WebElement formElement=driver.findElement(By.id("signup-form"));
		//String actualErrorMessage=formElement.findElement(By.tagName("div")).getText();
		String actualErrorMessage=driver.findElement(By.xpath(("//*[@id=\"signup-form\"]/div"))).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String message="There were problems creating your account.";
		assertEquals(actualErrorMessage, message);
	}
	@Test
	public void testForValidUserNameAndInvalidPasswordAndEmailID() {
		registerPage.setUsername("acapg");
		registerPage.setPassword("abhinav");
		registerPage.setEmailID("anskl@anfk.com");
		registerPage.clickSubmitButton();

		//WebElement formElement=driver.findElement(By.id("signup-form"));
	//	String actualErrorMessage=formElement.findElement(By.tagName("div")).getText();
		String actualErrorMessage=driver.findElement(By.xpath(("//*[@id=\"signup-form\"]/div"))).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String message="There were problems creating your account.";
		assertEquals(actualErrorMessage, message);
	}
	@Test
	public void testForValidUserNameAndPasswordAndInvalidEmailID() {
		registerPage.setUsername("acapg");
		registerPage.setPassword("indIa@123");
		registerPage.setEmailID("anskl@anfk.com");
		registerPage.clickSubmitButton();

		//WebElement formElement=driver.findElement(By.id("signup-form"));
		//String actualErrorMessage=formElement.findElement(By.tagName("div")).getText();
		String actualErrorMessage=driver.findElement(By.xpath(("//*[@id=\"signup-form\"]/div"))).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String message="There were problems creating your account.";
		assertEquals(actualErrorMessage, message);
		
	//	String actualMessage=driver.findElement(By.xpath("//meta[@class='css-truncate-target']")).getText(); 

	}
	
	
	@Test
	public void testForValidUserNameAndInvalidEmailIDAndValidPassword(){
		registerPage.setUsername("acpag");
		registerPage.setPassword("indIa@123");
		registerPage.setEmailID("a@g.com");
		registerPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath(("//*[@id=\"signup-form\"]/div"))).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String message="There were problems creating your account.";
		assertEquals(actualErrorMessage, message);
	}
	
	@Test
	public void testForInvalidUserNameAndValidEmailIDAndValidPassword() {
		registerPage.setUsername("achikoti");
		registerPage.setPassword("indIa@123");
		registerPage.setEmailID("ganeshm077@gmail.com");
		registerPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath(("//*[@id=\"signup-form\"]/div"))).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String message="There were problems creating your account.";
	}
	
	@Test
	public void testForInvalidUserNameAndInvalidEmailIDAndValidPassword() {
		registerPage.setUsername("achikoti");
		registerPage.setPassword("indIa@123");
		registerPage.setEmailID("a@g.com");
		registerPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath(("//*[@id=\"signup-form\"]/div"))).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String message="There were problems creating your account.";
	}
	
	@Test
	public void testForInvalidUserNameAndValidEmailIDAndInvalidPassword() {
		registerPage.setUsername("achikoti");
		registerPage.setPassword("xyz");
		registerPage.setEmailID("ganeshm077@gmail.com");
		registerPage.clickSubmitButton();
		String actualErrorMessage=driver.findElement(By.xpath(("//*[@id=\"signup-form\"]/div"))).getText();
		System.out.println("error Message:-"+actualErrorMessage);
		String message="There were problems creating your account.";
	}
	
	@Test
	public void testForValidUserNameAndPasswordAndEmailID() {
		registerPage.setUsername("acpag");
		registerPage.setPassword("indIa@123");
		registerPage.setEmailID("ganeshm077@gmail.com");
		registerPage.clickSubmitButton();
	}
	
@After
	public void tearDowntestEnv() {
		registerPage=null;
	}

	@AfterClass
	public static void tearDownDriverEnv() {
		driver.close();
		driver=null;

	}


}
