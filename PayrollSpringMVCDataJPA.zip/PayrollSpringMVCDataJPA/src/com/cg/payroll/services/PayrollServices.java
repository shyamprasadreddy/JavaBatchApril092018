package com.cg.payroll.services;

import java.sql.SQLException;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

public interface PayrollServices{

	int acceptAssociateDetails(Associate associate) throws AssociateDetailsNotFoundException,SQLException;

	Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException,SQLException;

	List<Associate> getAllAssociateDetails() throws SQLException;
	
	public boolean deleteAssociate(int associateId)throws SQLException;
	boolean updateAssociateDetails(Associate associate) throws SQLException;

	/*boolean acceptAssociateDetailsForUpdate(int associateId, String firstName, String lastName, String emailId,
			String department, String designation, String pancard, float yearlyInvestmentUnder80C, float basicSalary,
			float epf, float companyPf, float accountNumber, String bankName, String ifscCode)throws SQLException;
	boolean delete(Associate associate)throws SQLException;
	List<Associate> getAllAssociatesDetails() throws PayrollServicesDownException;
	int acceptAssociateDetails(String firstName, String lastName, String department, String designation, String pancard,
			String emailId, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf, int accountNumber,
			String bankName, String ifscCode) throws SQLException;
	
*/
}