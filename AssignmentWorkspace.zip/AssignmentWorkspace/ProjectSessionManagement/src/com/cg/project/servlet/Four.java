
package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.project.bean.User;

@WebServlet("/Four")
public class Four extends HttpServlet {
	private static final long serialVersionUID = 1L;
	

	public void init() {

	}

	public void destroy() {
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();

		PrintWriter out=response.getWriter();
		String phone=request.getParameter("phone");
		String email=request.getParameter("email");
		User user = (User) session.getAttribute("User");
		session.setAttribute("User", user);
		out.println("<html><body><div align='center'>Page4<form name='Three' action='Four' method='post'>");		
		out.println("<table><tr><td>firstName:</td><td>"+user.getFirstName()+"</td></tr>");
		out.println("<tr><td>lastName:</td><td>"+user.getLastName()+"</td></tr>");
		out.println("<tr><td>city:</td><td>"+user.getCity()+"</td></tr>");
		out.println("<tr><td>state:</td><td>"+user.getState()+"</td></tr>");
		out.println("<tr><td>phone:</td><td>"+phone+"</td></tr>");
		out.println("<tr><td>email:</td><td>"+email+"</td></tr></table></div></body></html>");
		
	}

}




