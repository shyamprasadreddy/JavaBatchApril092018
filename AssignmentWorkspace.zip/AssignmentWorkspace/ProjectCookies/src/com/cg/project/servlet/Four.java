
package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet("/Four")
public class Four extends HttpServlet {
	private static final long serialVersionUID = 1L;


	public void init() {
		
	}

	public void destroy() {
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String phone=request.getParameter("phone");
		String email=request.getParameter("email");		

		

		Cookie [] cookies = request.getCookies();
		String firstName ="" , lastName="",city="",state="";
		for (Cookie cookie : cookies) {
			if(cookie.getName().equals("firstName"))
				firstName =cookie.getValue();
			else if(cookie.getName().equals("lastName"))
				lastName=cookie.getValue();
			else if(cookie.getName().equals("city"))
				city=cookie.getValue();
			else if(cookie.getName().equals("state"))
				state=cookie.getValue();
		}

		out.println("<html><body><div align='center'>Page4<form name='Three' action='#' method='post'>");		
		out.println("<table><tr><td>firstName:</td><td>"+firstName+"</td></tr>");
		out.println("<tr><td>lastName:</td><td>"+lastName+"</td></tr>");
		out.println("<tr><td>city:</td><td>"+city+"</td></tr>");
		out.println("<tr><td>state:</td><td>"+state+"</td></tr>");
		out.println("<tr><td>city:</td><td>"+phone+"</td></tr>");
		out.println("<tr><td>state:</td><td>"+email+"</td></tr>");
		out.println("</table></div></body></html>");
			
	}

}




