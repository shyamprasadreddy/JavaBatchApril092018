package com.cg.project.servlet;

import java.io.IOException;
import java.io.PrintWriter;



import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



@WebServlet("/Two")
public class Two extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	public void init()  {
		
	}

	public void destroy() {
		// TODO Auto-generated method stub
	}

	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");		
		Cookie c1 = new  Cookie("firstName",firstName);
		Cookie c2 = new Cookie("lastName" ,lastName);
		response.addCookie(c1);
		response.addCookie(c2);
		out.println("<html><body><div align='center'>Page2<form name='Two' action='Three' method='post'>");		
		out.println("<table><tr><td>firstName:</td><td>"+firstName+"</td></tr>");
	//	out.println("<tr><td><input type='hidden' name='firstName' value='"+firstName+"'></td></tr>");
		out.println("<tr><td>lastName:</td><td>"+lastName+"</td></tr>");
	//	out.println("<tr><td><input type='hidden' name='lastName' value='"+lastName+"'></td></tr>");	
		out.println("<tr><td>city:</td><td><input type='text' size=25 name='city'></td></tr>");
		out.println("<tr><td>state:</td><td><input type='text' size=25 name='state'></td></tr>");
		out.println("<tr><td><input type='submit' value='enter'></td></tr>");
		out.println("</table></div></body></html>");
		
		
	}

}
