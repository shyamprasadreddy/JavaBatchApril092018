public class FibanociSeries{
public static void main(String str[]){  
	int x=0,y=0,z=1;
  for(int i=0;i<=5;i++){
	x=y;
	y=z;
	z=x+y;
	System.out.print(x+" " );
}
}  
}  