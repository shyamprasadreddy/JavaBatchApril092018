public class Swap{
public static void main(String str[]){  
	int a=10,b=20,c;
	a=a+b;
	b=a-b;
	a=a-b;
	System.out.println("a="+a+" "+"b="+b);
}  
}  