public class OddEven{
	public static void main(String[] str){
		int arr[] = {9,12,15,22,25,30};
		int n=arr.length;
		for(int i=1;i<=n-1;i++){
			if(arr[i]%2==0)
				System.out.println( arr[i] + "is a even number in the given range");
			else
				System.out.println( arr[i] + "is a odd number in the given range");
			}
		}
	}