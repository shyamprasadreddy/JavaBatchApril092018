public class MainClass1{
	public static void main(String str[]){
		for(int i=0;i<=10;i++)
		System.out.println(i);
	}
}