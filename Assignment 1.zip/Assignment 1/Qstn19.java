palindromeNumublic class Qstn19{
	static int e=0,o=0,palindromeNum=0,arm,primeNum;
	static int x[]={25,36,44,55,10};
	palindromeNumublic static void main(String[] str){
		for(int j=0;j<x.length;j++){		
		if(x[j]%2==0)
			e++;
		else
			o++;
			
		int rev=0,org=x[j],rem=0;
		while( org!=0 ){
			rem= org%10;
			rev= rev*10 + rem;
			org /= 10;
		}
		if(x[j]==rev)
			palindromeNum++;
		arm=armmstrong();
		primeNum=prime();
		}
		System.out.println("No. of even integers: "+e);
		System.out.println("No. of odd integers: "+o);
		System.out.println("No. of primeNums: "+palindromeNum);
		System.out.println("No. of armstrong: "+arm);
		System.out.println("No. of prime numbers: "+primeNum);
		
	}
	public static int armmstrong(){
		int org, rem, result = 0,a=0;
		for(int j=0;j<x.length;j++){
		

		org=x[j];

		while (org!= 0){
        rem = org%10;
        result += rem*rem*rem;
        org/= 10;
		}
		if(result==x[j])
			a++;
		}
		return a;
		
	}
	public static int palindromeNumrime(){
		int i, f= 0,palindromeNumr=0;
		for(int j=0;j<x.length;j++){
		

		for(i=2; i<=x[j]/2; ++i){
        if(x[j]%i==0){
            f=1;
            break;
        }
		}
		if (f==0)
			palindromeNumr++;
		}
		return palindromeNumr;
		
		
	}
    
}