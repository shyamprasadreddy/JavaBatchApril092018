public class Armstrong{
public static void main(String str[]){  
  int x,sum=0,temp;    
  int n=123;
  temp=n;    
  while(n>0){    
   x=n%10;  
   sum=sum+(x*x*x);    
   n=n/10;    
  	}    
  if(temp==sum)    
   System.out.println("Armstrong number ");    
  else    
   System.out.println("not Armstrong");    
}  
}  